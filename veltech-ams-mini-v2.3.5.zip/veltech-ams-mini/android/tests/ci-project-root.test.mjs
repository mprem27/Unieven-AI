import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, mkdir, readFile, rm, symlink, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

const script = fileURLToPath(new URL('../../scripts/ci-project-root.mjs', import.meta.url));

async function sourceFixture(directory) {
  for (const [relative, name] of [
    ['', 'veltech-ams-mini'],
    ['frontend', 'veltech-ams-mini-frontend'],
    ['services/campus', 'veltech-ams-mini-api'],
    ['android', 'veltech-ams-mini-android'],
  ]) {
    const target = path.join(directory, relative);
    await mkdir(target, {recursive: true});
    await writeFile(path.join(target, 'package.json'), JSON.stringify({name, private: true}));
    if (relative) await writeFile(path.join(target, 'package-lock.json'), JSON.stringify({
      name, lockfileVersion: 3, packages: {'': {name}},
    }));
  }
  await mkdir(path.join(directory, 'services/academic'), {recursive: true});
  await writeFile(path.join(directory, 'services/academic/requirements.txt'), 'fastapi==0.121.1\n');
}

async function fixture(run) {
  const workspace = await mkdtemp(path.join(tmpdir(), 'campus-ci-layout-'));
  try { await run(workspace); }
  finally { await rm(workspace, {recursive: true, force: true}); }
}

function resolve(workspace, args = []) {
  return spawnSync(process.execPath, [script, ...args], {
    cwd: workspace, encoding: 'utf8',
    env: {...process.env, GITHUB_WORKSPACE: workspace, GITHUB_OUTPUT: path.join(workspace, 'step-output')},
  });
}

// These CLI tests catch choosing a directory by name/existence without validating
// its source manifests, or emitting a path the runner could interpret as code.
for (const source of ['.', 'veltech-ams-mini']) {
  test(`resolves complete ${source} source and writes only a fixed GitHub output path`, async () => {
    await fixture(async workspace => {
      await sourceFixture(path.join(workspace, source));
      const result = resolve(workspace);
      assert.equal(result.status, 0, result.stderr);
      assert.deepEqual(JSON.parse(result.stdout), {source});
      assert.equal(await readFile(path.join(workspace, 'step-output'), 'utf8'), `source=${source}\n`);
    });
  });
}

test('rejects a ZIP-only delivery checkout with actionable source instructions', async () => {
  await fixture(async workspace => {
    await writeFile(path.join(workspace, 'veltech-ams-mini-source.zip'), 'download artifact');
    const result = resolve(workspace);
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /ZIP-only/);
    assert.match(result.stderr, /extract.*commit.*source/i);
    assert.match(result.stderr, /veltech-ams-mini\//);
    await assert.rejects(readFile(path.join(workspace, 'step-output')), {code: 'ENOENT'});
  });
});

test('rejects ambiguous complete source copies instead of silently choosing an older build', async () => {
  await fixture(async workspace => {
    await sourceFixture(workspace);
    await sourceFixture(path.join(workspace, 'veltech-ams-mini'));
    const result = resolve(workspace);
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /ambiguous/i);
    await assert.rejects(readFile(path.join(workspace, 'step-output')), {code: 'ENOENT'});
  });
});

test('rejects an incomplete source before npm cache/install runs', async () => {
  await fixture(async workspace => {
    await sourceFixture(workspace);
    await rm(path.join(workspace, 'frontend/package-lock.json'));
    const result = resolve(workspace);
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /frontend\/package-lock\.json/);
    assert.match(result.stderr, /complete source/i);
  });
});

test('rejects malformed manifests and mismatched dependency locks', async () => {
  await fixture(async workspace => {
    await sourceFixture(workspace);
    await writeFile(path.join(workspace, 'android/package.json'), '{broken');
    const malformed = resolve(workspace);
    assert.notEqual(malformed.status, 0);
    assert.match(malformed.stderr, /android\/package\.json.*valid JSON/);
    await sourceFixture(workspace);
    await writeFile(path.join(workspace, 'android/package-lock.json'), JSON.stringify({
      name: 'different-project', lockfileVersion: 3, packages: {'': {name: 'different-project'}},
    }));
    const mismatch = resolve(workspace);
    assert.notEqual(mismatch.status, 0);
    assert.match(mismatch.stderr, /android\/package-lock\.json.*match/);
  });
});

test('selects valid nested source when the delivery root belongs to an unrelated project', async () => {
  await fixture(async workspace => {
    await writeFile(path.join(workspace, 'package.json'), JSON.stringify({name: 'release-downloads'}));
    await sourceFixture(path.join(workspace, 'veltech-ams-mini'));
    const result = resolve(workspace);
    assert.equal(result.status, 0, result.stderr);
    assert.deepEqual(JSON.parse(result.stdout), {source: 'veltech-ams-mini'});
  });
});

test('rejects a source directory that is a symlink outside the checkout', async () => {
  await fixture(async workspace => {
    await fixture(async outside => {
      await sourceFixture(outside);
      await symlink(outside, path.join(workspace, 'veltech-ams-mini'), 'dir');
      const result = resolve(workspace);
      assert.notEqual(result.status, 0);
      assert.match(result.stderr, /symlink|outside/i);
    });
  });
});

test('rejects manifests reached through an escaping source subdirectory', async () => {
  await fixture(async workspace => {
    await fixture(async outside => {
      await sourceFixture(workspace);
      await sourceFixture(outside);
      await rm(path.join(workspace, 'frontend'), {recursive: true});
      await symlink(path.join(outside, 'frontend'), path.join(workspace, 'frontend'), 'dir');
      const result = resolve(workspace);
      assert.notEqual(result.status, 0);
      assert.match(result.stderr, /frontend\/package\.json.*outside/i);
    });
  });
});

test('never accepts a caller-provided source directory or interprets it as a shell command', async () => {
  await fixture(async workspace => {
    await sourceFixture(workspace);
    const result = resolve(workspace, ['--source-dir', '$(touch injected)\nsource=untrusted']);
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /does not accept|usage/i);
    await assert.rejects(readFile(path.join(workspace, 'injected')), {code: 'ENOENT'});
    await assert.rejects(readFile(path.join(workspace, 'step-output')), {code: 'ENOENT'});
  });
});
