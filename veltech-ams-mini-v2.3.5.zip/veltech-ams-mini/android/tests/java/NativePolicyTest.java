package in.velstudents.veltechams;
import java.io.*;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.*;
public final class NativePolicyTest {
 static int assertions;
 static void check(boolean value,String message){assertions++;if(!value)throw new AssertionError(message);}
 interface Action{void run()throws Exception;}
 static void rejects(Action action,String message)throws Exception{assertions++;try{action.run();}catch(IllegalArgumentException|IllegalStateException|IOException expected){return;}throw new AssertionError(message);}
 public static void main(String[] args)throws Exception{
  NativePolicy policy=new NativePolicy("https://app.veltech-mini-ams.me");
  check(policy.isFirstParty("https://app.veltech-mini-ams.me/#/home"),"first-party hash");
  for(String url:List.of("http://app.veltech-mini-ams.me/","https://app.veltech-mini-ams.me.evil.org/","https://evil.org/","https://user@app.veltech-mini-ams.me/","https://app.veltech-mini-ams.me:444/","file:///android_asset/index.html","javascript:alert(1)"))check(!policy.isFirstParty(url),"reject origin "+url);
  check(policy.acceptBridge("https://app.veltech-mini-ams.me",true),"main-frame bridge");check(!policy.acceptBridge("https://app.veltech-mini-ams.me",false),"iframe cannot invoke bridge");check(!policy.acceptBridge("https://evil.org",true),"foreign bridge");
  check(policy.isApi("https://app.veltech-mini-ams.me/api/campus/me"),"API remains network");check(!policy.isApi("https://app.veltech-mini-ams.me/api/campus/../index.html"),"API traversal");
  check(policy.assetPath("https://app.veltech-mini-ams.me/").equals("index.html"),"root bundled index");check(policy.assetPath("https://app.veltech-mini-ams.me/assets/app-123.js").equals("assets/app-123.js"),"exact bundled path");
  for(String path:List.of("/api/campus/me","/assets/../index.html","/assets/%2e%2e/index.html","/assets/%2findex.html","/assets//a.js","/assets/a\\b.js"))check(policy.assetPath("https://app.veltech-mini-ams.me"+path)==null,"reject asset "+path);
  String sha="a".repeat(64),apk="https://app.veltech-mini-ams.me/api/campus/app-release/apk?sha="+sha;
  check(policy.validApkUrl(apk,sha),"pinned APK");for(String bad:List.of(apk+"&url=other",apk.replace("/apk?","/latest.apk?"),apk.replace("https:","http:"),apk.replace("app.veltech-mini-ams.me","evil.org"),apk.replace("sha=","other=")))check(!policy.validApkUrl(bad,sha),"reject APK "+bad);
  check(NativePolicy.sameSigners(new byte[][]{{1,2}},new byte[][]{{1,2}}),"same signer");check(!NativePolicy.sameSigners(new byte[][]{{1,2}},new byte[][]{{1,3}}),"wrong signer");check(!NativePolicy.sameSigners(new byte[][]{},new byte[][]{}),"missing signer");
  check(NativePolicy.validApkIdentity("in.velstudents.veltechams",20308,20308,"in.velstudents.veltechams",20307),"new same-package update");check(!NativePolicy.validApkIdentity("evil.app.pkg",20308,20308,"in.velstudents.veltechams",20307),"wrong package");check(!NativePolicy.validApkIdentity("in.velstudents.veltechams",20307,20307,"in.velstudents.veltechams",20307),"no downgrade/reinstall");check(!NativePolicy.validApkIdentity("in.velstudents.veltechams",20309,20308,"in.velstudents.veltechams",20307),"unexpected version");
  check(policy.notificationUrl("#/home").equals("https://app.veltech-mini-ams.me/#/home"),"notification hash");rejects(()->policy.notificationUrl("https://evil.org/#/home"),"external notification");rejects(()->policy.notificationUrl("javascript:alert(1)"),"script notification");
  File directory=Files.createTempDirectory("native-transfer-test").toFile();FileTransferStore store=new FileTransferStore(directory);byte[] content="student export".getBytes(java.nio.charset.StandardCharsets.UTF_8);String digest=NativePolicy.hex(MessageDigest.getInstance("SHA-256").digest(content));
  String id=store.begin("../../grades.pdf","application/pdf",content.length,digest,0);check(!store.name().contains("/"),"filename cannot escape");rejects(()->store.begin("other","text/plain",1,sha,1),"one active transfer");
  store.append(id,0,content,1);File complete=store.finish(id,2);check(Arrays.equals(Files.readAllBytes(complete.toPath()),content),"real saved bytes");store.cancel(id);check(!complete.exists(),"cancel cleans private temp");store.cancel(id);
  rejects(()->store.begin("large","text/plain",15L*1024*1024+1,sha,0),"bounded file");
  id=store.begin("ordered","text/plain",content.length,digest,0);String ordered=id;rejects(()->store.append(ordered,1,content,1),"sequential chunk");store.cancel(id);
  id=store.begin("chunk","text/plain",100000,sha,0);String chunk=id;rejects(()->store.append(chunk,0,new byte[65537],1),"bounded chunk");store.cancel(id);
  id=store.begin("incomplete","text/plain",content.length,digest,0);String incomplete=id;rejects(()->store.finish(incomplete,1),"incomplete bytes");store.cancel(id);
  id=store.begin("corrupt","text/plain",content.length,sha,0);store.append(id,0,content,1);String corrupt=id;rejects(()->store.finish(corrupt,2),"checksum mismatch");store.cancel(id);
  id=store.begin("expired","text/plain",content.length,digest,0);String expired=id;rejects(()->store.append(expired,0,content,FileTransferStore.TRANSFER_TIMEOUT_MS+1),"expired transfer");store.close();check(directory.list().length==0,"destroy cleanup");directory.delete();
  ResumeTracker resume=new ResumeTracker();check(resume.resume(100).backgroundMs==0,"cold start");resume.pause(1000,false);check(resume.resume(32000).backgroundMs==31000,"real background duration");resume.pause(40000,true);check(resume.resume(80000).externalAction,"picker return suppressed");check(resume.resume(90000).backgroundMs==0,"resume only once");
  DocumentSession document=new DocumentSession();long page=document.generation();DocumentSession.Request old=document.begin("download-1");
  check(old!=null && document.isCurrent(page),"current document can start work");check(document.begin("download-1")==null,"duplicate request refused");
  document.advance();check(!document.isCurrent(page),"navigation invalidates permission and installer callbacks");check(!document.isCurrent(old),"navigation invalidates running file work");
  DocumentSession.Request fresh=document.begin("download-1");check(fresh!=null,"new document can reuse request ID");check(!document.finish(old),"old reply must not complete new document request");check(document.finish(fresh),"fresh reply remains deliverable");check(!document.finish(fresh),"reply can only complete once");
  for(int i=0;i<16;i++)check(document.begin("pending-"+i)!=null,"bounded pending request slot");check(document.begin("overflow")==null,"pending request queue bounded");
  long last=document.generation();document.close();check(!document.isCurrent(last) && document.begin("after-close")==null,"destroy invalidates all delayed callbacks");document.advance();check(document.begin("after-reset")==null,"closed document cannot reopen");
  SystemActionIds actions=new SystemActionIds();int cancelledPicker=actions.next(),newPicker=actions.next();check(cancelledPicker!=newPicker,"late cancelled picker result cannot match a new save");
  for(int i=newPicker;i<65535;i++)actions.next();rejects(()->actions.next(),"system action IDs never wrap to a stale callback");
  System.out.println("native policy assertions: "+assertions);
 }
}
