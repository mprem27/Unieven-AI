import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=fileURLToPath(new URL('../../',import.meta.url));
test('native origin, transfer, lifecycle and APK trust policies execute on the JVM',async()=>{
 const out=await mkdtemp(path.join(tmpdir(),'native-policy-'));const javaRoot=path.join(root,'android/native-template/app/src/main/java/in/velstudents/veltechams');
 try{const compile=spawnSync('javac',['-d',out,...['NativePolicy.java','FileTransferStore.java','ResumeTracker.java','DocumentSession.java','SystemActionIds.java'].map(file=>path.join(javaRoot,file)),path.join(root,'android/tests/java/NativePolicyTest.java')],{encoding:'utf8'});assert.equal(compile.status,0,compile.stderr);
  const run=spawnSync('java',['-cp',out,'in.velstudents.veltechams.NativePolicyTest'],{encoding:'utf8'});assert.equal(run.status,0,run.stdout+run.stderr);assert.match(run.stdout,/native policy assertions: \d+/);
 }finally{await rm(out,{recursive:true,force:true});}
});
