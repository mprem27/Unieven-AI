import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdtemp,rm,writeFile,mkdir,symlink,cp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {validateConfig,GRADLE_SHA256} from '../../scripts/android-config.mjs';
import {APP_ICON_192,APP_ICON_512,APP_LOGO,APP_VERSION} from '../../shared/app-branding.mjs';
import * as preparation from '../../scripts/android-prepare.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url));
const config=validateConfig({deploymentUrl:'https://campus.velstudents.in',packageId:'in.velstudents.veltechams',appName:'Veltech AMS mini',launcherName:'Veltech mini',versionName:APP_VERSION,versionCode:20307,signingKeyFile:'velstudents-release.keystore',signingKeyAlias:'velstudents'});
async function fixture(directory){
 await mkdir(path.join(directory,'assets'),{recursive:true});await mkdir(path.join(directory,'icons'),{recursive:true});
 await writeFile(path.join(directory,'index.html'),'<!doctype html><html><script type="module" src="/assets/app-123.js"></script></html>');
 await writeFile(path.join(directory,'assets/app-123.js'),'document.title="Veltech";');
 for(const asset of [APP_ICON_192,APP_ICON_512,APP_LOGO])await writeFile(path.join(directory,asset),await readFile(path.join(root,'frontend/public',asset)));
 await writeFile(path.join(directory,'app-build.json'),JSON.stringify({version:config.versionName,logo:APP_LOGO,icon192:APP_ICON_192,icon512:APP_ICON_512}));
}
test('default preparation plans a bundled native runtime without requiring live deployment',async()=>{
 const temporary=await mkdtemp(path.join(tmpdir(),'native-cli-'));
 try{const file=path.join(temporary,'config.json');await writeFile(file,JSON.stringify(config));
  for(const name of ['android-prepare.mjs','android-build.mjs']){const result=spawnSync(process.execPath,[path.join(root,'scripts',name),'--config',file,'--dry-run'],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);const plan=JSON.parse(result.stdout);assert.equal(plan.runtime,'android-native');assert.equal(plan.deploymentUrl,config.deploymentUrl);assert.match(plan.note,/No network/);}
 }finally{await rm(temporary,{recursive:true,force:true});}
});
test('generator bundles validated local assets and a hardened standalone Android activity',async()=>{
 assert.equal(typeof preparation.localWebResources,'function','Native packaging must accept the local frontend build');
 const temporary=await mkdtemp(path.join(tmpdir(),'native-generate-'));
 try{const web=path.join(temporary,'web'),target=path.join(temporary,'android');await fixture(web);await preparation.generateProject(config,target,await preparation.localWebResources(config,web));
  const xml=await readFile(path.join(target,'app/src/main/AndroidManifest.xml'),'utf8');
  assert.match(xml,/android:name="\.MainActivity"/);assert.match(xml,/android:allowBackup="false"/);assert.match(xml,/android:usesCleartextTraffic="false"/);assert.doesNotMatch(xml,/trusted|customtabs|autoVerify/);
  const gradle=await readFile(path.join(target,'app/build.gradle'),'utf8');assert.match(gradle,/androidx.webkit:webkit:/);assert.doesNotMatch(gradle,/androidbrowserhelper|bubblewrap/);assert.match(gradle,/buildToolsVersion "36\.1\.0"/);assert.match(gradle,/versionCode 20307/);
  assert.equal((await readFile(path.join(target,'app/src/main/assets/web/assets/app-123.js'),'utf8')),'document.title="Veltech";');
  const build=JSON.parse(await readFile(path.join(target,'velstudents-build.json'),'utf8'));assert.equal(build.runtime,'android-native');assert.equal(build.webVersion,APP_VERSION);assert.equal(build.assetSha256.length,64);
  assert.equal(createHash('sha256').update(await readFile(path.join(target,'gradle/wrapper/gradle-wrapper.jar'))).digest('hex'),preparation.WRAPPER_SHA256);
  assert.match(await readFile(path.join(target,'gradle/wrapper/gradle-wrapper.properties'),'utf8'),new RegExp(`distributionSha256Sum=${GRADLE_SHA256}`));
 }finally{await rm(temporary,{recursive:true,force:true});}
});
test('local packaging rejects stale build metadata, links, API collisions and missing entry assets',async()=>{
 assert.equal(typeof preparation.localWebResources,'function');const temporary=await mkdtemp(path.join(tmpdir(),'native-reject-'));
 try{await fixture(temporary);await writeFile(path.join(temporary,'app-build.json'),JSON.stringify({version:'0.0.0',logo:APP_LOGO,icon192:APP_ICON_192,icon512:APP_ICON_512}));await assert.rejects(preparation.localWebResources(config,temporary),/version|metadata/i);
  await fixture(temporary);await symlink(path.join(temporary,'index.html'),path.join(temporary,'linked.html'));await assert.rejects(preparation.localWebResources(config,temporary),/symlink|symbolic/i);await rm(path.join(temporary,'linked.html'));
  await mkdir(path.join(temporary,'api/campus'),{recursive:true});await writeFile(path.join(temporary,'api/campus/me'),'stale account');await assert.rejects(preparation.localWebResources(config,temporary),/API|api/);await rm(path.join(temporary,'api'),{recursive:true});
  await rm(path.join(temporary,'assets/app-123.js'));await assert.rejects(preparation.localWebResources(config,temporary),/missing|referenced/i);
 }finally{await rm(temporary,{recursive:true,force:true});}
});
test('source archives without empty template directories still generate the Gradle wrapper',async()=>{
 const temporary=await mkdtemp(path.join(tmpdir(),'native-source-archive-'));
 try{
  for(const file of ['scripts/android-config.mjs','scripts/android-native-assets.mjs','scripts/android-prepare.mjs','shared/app-branding.mjs','android/gradle/gradle-wrapper.jar']){
   const destination=path.join(temporary,file);await mkdir(path.dirname(destination),{recursive:true});await cp(path.join(root,file),destination);
  }
  await cp(path.join(root,'android/native-template'),path.join(temporary,'android/native-template'),{recursive:true});
  await rm(path.join(temporary,'android/native-template/gradle'),{recursive:true,force:true});
  const web=path.join(temporary,'web');await fixture(web);
  const archived=await import(pathToFileURL(path.join(temporary,'scripts/android-prepare.mjs')).href);
  const target=path.join(temporary,'generated');await archived.generateProject(config,target,await archived.localWebResources(config,web));
  assert.equal(createHash('sha256').update(await readFile(path.join(target,'gradle/wrapper/gradle-wrapper.jar'))).digest('hex'),preparation.WRAPPER_SHA256);
 }finally{await rm(temporary,{recursive:true,force:true});}
});
