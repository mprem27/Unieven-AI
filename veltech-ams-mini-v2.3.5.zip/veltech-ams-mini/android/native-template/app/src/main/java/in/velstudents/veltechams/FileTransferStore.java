package in.velstudents.veltechams;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

/** One bounded transfer; the caller never chooses an app-private path. */
public final class FileTransferStore implements Closeable {
    public static final long TRANSFER_TIMEOUT_MS = 120_000;
    private final File directory;
    private String id, name, mime, expectedSha;
    private File file;
    private FileOutputStream output;
    private MessageDigest digest;
    private long expectedBytes, bytes, started;
    private int nextIndex;
    private boolean ready;

    public FileTransferStore(File directory) throws IOException {
        this.directory = directory;
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Cannot create private transfer storage.");
        File[] stale = directory.listFiles();
        if (stale != null) for (File value : stale) if (value.isFile()) value.delete();
    }

    public synchronized String begin(String requestedName, String requestedMime, long count, String sha256, long now) throws IOException {
        if (id != null && now - started > TRANSFER_TIMEOUT_MS && !ready) close();
        if (id != null) throw new IllegalStateException("Finish or cancel the active file first.");
        if (count < 0 || count > NativePolicy.MAX_FILE_BYTES || !NativePolicy.validSha256(sha256)
                || requestedMime == null || !requestedMime.matches("[a-zA-Z0-9.+-]{1,80}/[a-zA-Z0-9.+-]{1,80}"))
            throw new IllegalArgumentException("Invalid file size, checksum or MIME type.");
        name = NativePolicy.safeFileName(requestedName); mime = requestedMime; expectedBytes = count; expectedSha = sha256;
        try { digest = MessageDigest.getInstance("SHA-256"); } catch (NoSuchAlgorithmException error) { throw new IllegalStateException(error); }
        file = File.createTempFile("transfer-", ".tmp", directory); output = new FileOutputStream(file);
        id = UUID.randomUUID().toString(); started = now; bytes = 0; nextIndex = 0; ready = false;
        return id;
    }

    private void active(String transferId, long now) throws IOException {
        if (id == null || !id.equals(transferId)) throw new IllegalArgumentException("Unknown file transfer.");
        if (now - started > TRANSFER_TIMEOUT_MS && !ready) { close(); throw new IOException("The file transfer expired. Try again."); }
    }

    public synchronized void append(String transferId, int index, byte[] chunk, long now) throws IOException {
        active(transferId, now);
        if (ready || index != nextIndex || chunk == null || chunk.length == 0 || chunk.length > NativePolicy.MAX_CHUNK_BYTES
                || bytes + chunk.length > expectedBytes) throw new IllegalArgumentException("Invalid file chunk or sequence.");
        output.write(chunk); digest.update(chunk); bytes += chunk.length; nextIndex++;
    }

    public synchronized File finish(String transferId, long now) throws IOException {
        active(transferId, now);
        if (ready) throw new IllegalStateException("The save picker is already open.");
        if (bytes != expectedBytes) throw new IOException("The file is incomplete.");
        output.close(); output = null;
        if (!NativePolicy.hex(digest.digest()).equals(expectedSha)) { close(); throw new IOException("The file checksum did not match."); }
        ready = true; return file;
    }

    public synchronized String name() { return name; }
    public synchronized String mimeType() { return mime; }
    public synchronized File completedFile() {
        if (!ready) throw new IllegalStateException("The file has not been verified.");
        return file;
    }
    public synchronized void cancel(String transferId) throws IOException { if (id != null && id.equals(transferId)) close(); }
    public synchronized void expire(long now) throws IOException { if (id != null && !ready && now - started > TRANSFER_TIMEOUT_MS) close(); }
    @Override public synchronized void close() throws IOException {
        try { if (output != null) output.close(); }
        finally { output = null; if (file != null) file.delete(); file = null; id = null; ready = false; digest = null; }
    }
}
