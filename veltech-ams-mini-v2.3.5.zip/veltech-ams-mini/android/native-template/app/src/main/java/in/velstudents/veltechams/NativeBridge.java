package in.velstudents.veltechams;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.webkit.WebView;
import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import org.json.JSONObject;
import java.io.Closeable;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Origin restriction is enforced by AndroidX and again for every main-frame call. */
final class NativeBridge implements WebViewCompat.WebMessageListener, Closeable {
    interface Completion { void complete(JSONObject result, String error); }
    interface Host {
        JSONObject hello() throws Exception;
        void saveFile(String transferId, String name, String mime, File file, Completion done);
        void cancelSave(String transferId);
        void share(JSONObject payload, Completion done) throws Exception;
        void downloadApk(JSONObject payload, Completion done) throws Exception;
        void notificationPermission(Completion done);
        void notifyUser(JSONObject payload, Completion done) throws Exception;
    }
    private final NativePolicy policy;
    private final Host host;
    private final FileTransferStore transfers;
    private final DocumentSession documents;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean closed;
    NativeBridge(NativePolicy policy, Host host, File cacheDirectory, DocumentSession documents) throws Exception {
        this.policy = policy; this.host = host; this.documents = documents;
        transfers = new FileTransferStore(new File(cacheDirectory,"transfers"));
    }
    @Override public void onPostMessage(WebView view, WebMessageCompat message, Uri sourceOrigin, boolean mainFrame, JavaScriptReplyProxy proxy) {
        if (closed || !policy.acceptBridge(sourceOrigin.toString(), mainFrame) || !policy.isAppDocument(view.getUrl())) return;
        if (message.getType() != WebMessageCompat.TYPE_STRING) return;
        String text = message.getData();
        if (text == null || text.length() > NativePolicy.MAX_MESSAGE_BYTES || text.getBytes(StandardCharsets.UTF_8).length > NativePolicy.MAX_MESSAGE_BYTES) return;
        String id;
        JSONObject request;
        try { request = new JSONObject(text); id = string(request,"id",80); if (!id.matches("[A-Za-z0-9._:-]+")) return; }
        catch (Exception error) { return; }
        DocumentSession.Request owner = documents.begin(id);
        if (owner == null) return;
        Completion done = (result,error) -> main.post(() -> {
            if (closed || !documents.finish(owner)) return;
            try {
                JSONObject reply = new JSONObject().put("id",id).put("ok",error == null);
                if (error == null) reply.put("result", result == null ? new JSONObject() : result);
                else reply.put("error",error.substring(0,Math.min(error.length(),240)));
                proxy.postMessage(reply.toString());
            } catch (Exception ignored) { /* The originating document may have closed. */ }
        });
        try {
            String type = string(request,"type",40);
            JSONObject payload = request.optJSONObject("payload");
            if (payload == null) payload = new JSONObject();
            final JSONObject data = payload;
            switch (type) {
                case "hello": done.complete(host.hello(),null); break;
                case "beginFile": background(owner,done,() -> {
                    String transfer = transfers.begin(string(data,"name",240),string(data,"mimeType",161),integer(data,"bytes",0,NativePolicy.MAX_FILE_BYTES),string(data,"sha256",64),SystemClock.elapsedRealtime());
                    main.postDelayed(() -> { if (!closed) worker.execute(() -> { try { transfers.expire(SystemClock.elapsedRealtime()); } catch (Exception ignored) {} }); },FileTransferStore.TRANSFER_TIMEOUT_MS + 1000);
                    done.complete(new JSONObject().put("transferId",transfer),null);
                }); break;
                case "appendFile": background(owner,done,() -> {
                    String encoded = string(data,"base64",87_384);
                    if (!NativePolicy.validBase64Chunk(encoded)) throw new IllegalArgumentException("Invalid file chunk encoding.");
                    byte[] bytes = Base64.decode(encoded,Base64.NO_WRAP);
                    transfers.append(string(data,"transferId",80),(int)integer(data,"index",0,10000),bytes,SystemClock.elapsedRealtime());
                    done.complete(new JSONObject().put("appended",true),null);
                }); break;
                case "finishFile": background(owner,done,() -> {
                    String transfer = string(data,"transferId",80);
                    File file = transfers.finish(transfer,SystemClock.elapsedRealtime());
                    String name = transfers.name(), mime = transfers.mimeType();
                    main.post(() -> {
                        if (closed || !documents.isCurrent(owner)) return;
                        host.saveFile(transfer,name,mime,file,(result,error) -> {
                            if (!closed) worker.execute(() -> { try { transfers.cancel(transfer); } catch (Exception ignored) {} done.complete(result,error); });
                        });
                    });
                }); break;
                case "cancelFile": {
                    String transfer = string(data,"transferId",80); host.cancelSave(transfer);
                    background(owner,done,() -> { transfers.cancel(transfer); done.complete(new JSONObject().put("cancelled",true),null); }); break;
                }
                case "share": host.share(data,done); break;
                case "downloadApk": host.downloadApk(data,done); break;
                case "notificationPermission": host.notificationPermission(done); break;
                case "notify": host.notifyUser(data,done); break;
                default: throw new IllegalArgumentException("Unsupported native action.");
            }
        } catch (Exception error) { done.complete(null,safeError(error)); }
    }
    interface Work { void run() throws Exception; }
    private void background(DocumentSession.Request owner, Completion done, Work action) {
        worker.execute(() -> { if (closed || !documents.isCurrent(owner)) return; try { action.run(); } catch (Exception error) { done.complete(null,safeError(error)); } });
    }
    void documentChanged() {
        if (!closed) worker.execute(() -> { try { transfers.close(); } catch (Exception ignored) {} });
    }
    static String string(JSONObject object, String key, int max) throws Exception {
        Object value = object.get(key);
        if (!(value instanceof String) || ((String)value).length() > max || ((String)value).isEmpty()) throw new IllegalArgumentException("Invalid " + key + ".");
        return (String)value;
    }
    static long integer(JSONObject object, String key, long min, long max) throws Exception {
        Object value = object.get(key);
        if (!(value instanceof Number)) throw new IllegalArgumentException("Invalid " + key + ".");
        double number = ((Number)value).doubleValue();
        if (!Double.isFinite(number) || number != Math.rint(number) || number < min || number > max) throw new IllegalArgumentException("Invalid " + key + ".");
        return ((Number)value).longValue();
    }
    static String safeError(Exception error) {
        return error instanceof IllegalArgumentException || error instanceof IllegalStateException || error instanceof java.io.IOException
                ? (error.getMessage() == null ? "The native action failed." : error.getMessage()) : "The native action could not be completed.";
    }
    @Override public void close() {
        closed = true; documents.close(); main.removeCallbacksAndMessages(null);
        worker.execute(() -> { try { transfers.close(); } catch (Exception ignored) {} }); worker.shutdown();
    }
}
