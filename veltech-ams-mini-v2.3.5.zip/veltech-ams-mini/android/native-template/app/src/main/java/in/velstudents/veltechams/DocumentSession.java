package in.velstudents.veltechams;

import java.util.HashMap;
import java.util.Map;

/** A callback belongs to one document, even if the next document reuses its ID. */
public final class DocumentSession {
    public static final class Request {
        private final String id;
        private final long generation;
        private Request(String id, long generation) { this.id = id; this.generation = generation; }
    }
    private long generation;
    private boolean closed;
    private final Map<String,Request> pending = new HashMap<>();
    public synchronized long generation() { return generation; }
    public synchronized boolean isCurrent(long value) { return !closed && generation == value; }
    public synchronized Request begin(String id) {
        if (closed || pending.containsKey(id) || pending.size() >= 16) return null;
        Request request = new Request(id,generation); pending.put(id,request); return request;
    }
    public synchronized boolean isCurrent(Request request) {
        return request != null && isCurrent(request.generation) && pending.get(request.id) == request;
    }
    public synchronized boolean finish(Request request) {
        if (!isCurrent(request)) return false;
        pending.remove(request.id); return true;
    }
    public synchronized void advance() { generation++; pending.clear(); }
    public synchronized void close() { closed = true; advance(); }
}
