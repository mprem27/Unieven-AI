package in.velstudents.veltechams;

import android.content.Context;
import android.net.Uri;
import android.net.http.SslError;
import android.graphics.Bitmap;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Only the packaged allowlist is served locally; /api/campus/ stays HTTPS network. */
final class BundledWebClient extends WebViewClient {
    interface ExternalLink { void open(String url); }
    private final NativePolicy policy;
    private final WebViewAssetLoader loader;
    private final ExternalLink external;
    private final Runnable documentStarted;
    private final Set<String> assets = new HashSet<>();
    BundledWebClient(Context context, NativePolicy policy, ExternalLink external, Runnable documentStarted) throws IOException {
        this.policy = policy; this.external = external; this.documentStarted = documentStarted;
        try (BufferedReader input = new BufferedReader(new InputStreamReader(context.getAssets().open("asset-paths.txt"), java.nio.charset.StandardCharsets.UTF_8))) {
            String name; while ((name = input.readLine()) != null) assets.add(name);
        }
        loader = new WebViewAssetLoader.Builder().setDomain(Uri.parse(policy.origin).getHost()).setHttpAllowed(false)
                .addPathHandler("/", path -> {
                    String name = path.isEmpty() ? "index.html" : path;
                    if (!assets.contains(name)) return blocked();
                    try {
                        Map<String,String> headers = new HashMap<>();
                        headers.put("Cache-Control", "no-store"); headers.put("X-Content-Type-Options", "nosniff");
                        headers.put("Referrer-Policy", "same-origin");
                        headers.put("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self' data:; connect-src 'self'; worker-src 'none'; frame-src 'none'; child-src 'none'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'; form-action 'self'");
                        return new WebResourceResponse(mime(name), "UTF-8", 200, "OK", headers, context.getAssets().open("web/" + name));
                    } catch (IOException error) { return blocked(); }
                }).build();
    }
    @Override public void onPageStarted(WebView view, String url, Bitmap favicon) { documentStarted.run(); }
    @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        String url = request.getUrl().toString();
        if (!policy.isFirstParty(url)) return blocked();
        if (policy.isApi(url) && !request.isForMainFrame()) return null;
        if (!"GET".equals(request.getMethod()) || (request.isForMainFrame() && !policy.isAppDocument(url))) return blocked();
        String name = policy.assetPath(url);
        if (name == null || !assets.contains(name)) return blocked();
        WebResourceResponse response = loader.shouldInterceptRequest(request.getUrl());
        return response == null ? blocked() : response;
    }
    @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        String url = request.getUrl().toString();
        if (policy.isAppDocument(url) && request.isForMainFrame()) return false;
        if (request.isForMainFrame() && request.hasGesture() && NativePolicy.safeExternalHttps(url)) external.open(url);
        return true;
    }
    @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) { handler.cancel(); }
    private static WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", java.util.Collections.singletonMap("Cache-Control", "no-store"), new ByteArrayInputStream(new byte[0]));
    }
    private static String mime(String name) {
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "application/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".json") || lower.endsWith(".webmanifest")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".woff")) return "font/woff";
        if (lower.endsWith(".woff2")) return "font/woff2";
        if (lower.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }
}
