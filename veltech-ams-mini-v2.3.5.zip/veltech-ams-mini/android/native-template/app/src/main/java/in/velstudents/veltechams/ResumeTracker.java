package in.velstudents.veltechams;

/** Uses monotonic time. External Android UI must never count as an app opening. */
public final class ResumeTracker {
    private long pausedAt = -1;
    private boolean external;
    public static final class Return {
        public final long backgroundMs;
        public final boolean externalAction;
        Return(long backgroundMs, boolean externalAction) { this.backgroundMs = backgroundMs; this.externalAction = externalAction; }
    }
    public void pause(long now, boolean externalAction) { pausedAt = now; external = externalAction; }
    public Return resume(long now) {
        Return value = new Return(pausedAt < 0 ? 0 : Math.max(0, now - pausedAt), external);
        pausedAt = -1; external = false; return value;
    }
}
