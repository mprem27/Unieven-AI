package in.velstudents.veltechams;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.SystemClock;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.URL;
import java.security.MessageDigest;
import javax.net.ssl.HttpsURLConnection;

/** Runs on a worker. No redirect, alternate host, signer change or downgrade is accepted. */
final class NativeApkUpdater {
    static File download(Context context, NativePolicy policy, String url, String sha, long version) throws Exception {
        if (!policy.validApkUrl(url,sha)) throw new IllegalArgumentException("Use the verified first-party APK endpoint.");
        if (version <= BuildConfig.VERSION_CODE) throw new IllegalArgumentException("This update is not newer than the installed app.");
        File directory = new File(context.getCacheDir(),"updates");
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Cannot create private update storage.");
        File file = File.createTempFile("verified-update-",".apk",directory);
        HttpsURLConnection connection = null;
        boolean verified = false;
        try {
            connection = (HttpsURLConnection)new URL(url).openConnection();
            connection.setInstanceFollowRedirects(false); connection.setConnectTimeout(15_000); connection.setReadTimeout(20_000);
            connection.setRequestProperty("Accept","application/vnd.android.package-archive");
            // Public APK endpoint: do not copy browser cookies or authentication headers.
            if (connection.getResponseCode() != 200) throw new IOException("The APK download was refused or redirected. Check for updates again.");
            long expected = connection.getContentLengthLong();
            if (expected < 1000 || expected > NativePolicy.MAX_APK_BYTES) throw new IOException("Invalid APK download size.");
            String type = connection.getContentType();
            if (type == null || !(type.startsWith("application/vnd.android.package-archive") || type.startsWith("application/octet-stream"))) throw new IOException("The server did not return an APK.");
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            long total = 0, started = SystemClock.elapsedRealtime();
            try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(file)) {
                byte[] bytes = new byte[64 * 1024]; int count;
                while ((count = input.read(bytes)) != -1) {
                    total += count;
                    if (total > expected || total > NativePolicy.MAX_APK_BYTES || SystemClock.elapsedRealtime() - started > 120_000 || Thread.currentThread().isInterrupted()) throw new IOException("The APK download exceeded its size or time limit.");
                    output.write(bytes,0,count); digest.update(bytes,0,count);
                }
            }
            if (total != expected || !NativePolicy.hex(digest.digest()).equals(sha)) throw new IOException("The APK checksum did not match. Check for updates again.");
            PackageManager manager = context.getPackageManager();
            int flags = Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
            PackageInfo candidate = manager.getPackageArchiveInfo(file.getAbsolutePath(),flags);
            PackageInfo installed = manager.getPackageInfo(context.getPackageName(),flags);
            long code = candidate == null ? 0 : Build.VERSION.SDK_INT >= 28 ? candidate.getLongVersionCode() : candidate.versionCode;
            long current = Build.VERSION.SDK_INT >= 28 ? installed.getLongVersionCode() : installed.versionCode;
            if (candidate == null || !NativePolicy.validApkIdentity(candidate.packageName,code,version,installed.packageName,current)
                    || !NativePolicy.sameSigners(signers(installed),signers(candidate))) throw new IOException("The APK package, version or signing identity does not match this app.");
            verified = true; return file;
        } finally { if (connection != null) connection.disconnect(); if (!verified) file.delete(); }
    }
    private static byte[][] signers(PackageInfo info) {
        Signature[] signatures = Build.VERSION.SDK_INT >= 28 && info.signingInfo != null ? info.signingInfo.getApkContentsSigners() : info.signatures;
        if (signatures == null) return new byte[0][];
        byte[][] result = new byte[signatures.length][];
        for (int i = 0; i < signatures.length; i++) result[i] = signatures[i].toByteArray();
        return result;
    }
}
