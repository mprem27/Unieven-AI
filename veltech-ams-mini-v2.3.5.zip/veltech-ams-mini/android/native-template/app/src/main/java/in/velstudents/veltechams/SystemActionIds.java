package in.velstudents.veltechams;

/** Android returns only a request code: never recycle one within an Activity. */
public final class SystemActionIds {
    private int last = 99;
    public int next() {
        if (last >= 65535) throw new IllegalStateException("Reopen the app before starting another system action.");
        return ++last;
    }
}
