package in.velstudents.veltechams;

import java.net.URI;
import java.security.MessageDigest;
import java.util.Arrays;

/** Android-free security decisions. The WebView and bridge both use this policy. */
public final class NativePolicy {
    public static final int MAX_MESSAGE_BYTES = 98_304;
    public static final int MAX_CHUNK_BYTES = 65_536;
    public static final long MAX_FILE_BYTES = 15L * 1024 * 1024;
    public static final long MAX_APK_BYTES = 250L * 1024 * 1024;
    public final String origin;
    private final String host;

    public NativePolicy(String origin) {
        URI uri = URI.create(origin);
        if (!"https".equals(uri.getScheme()) || uri.getHost() == null || uri.getPort() != -1
                || uri.getRawUserInfo() != null || !origin.equals("https://" + uri.getHost()))
            throw new IllegalArgumentException("A plain HTTPS origin is required.");
        this.origin = origin;
        this.host = uri.getHost();
    }

    public boolean isFirstParty(String value) {
        try {
            URI uri = URI.create(value);
            return "https".equals(uri.getScheme()) && host.equals(uri.getHost())
                    && (uri.getPort() == -1 || uri.getPort() == 443) && uri.getRawUserInfo() == null;
        } catch (RuntimeException error) { return false; }
    }

    public boolean acceptBridge(String sourceOrigin, boolean mainFrame) {
        // AndroidX passes an origin, never a document path. Require its exact form.
        return mainFrame && origin.equals(sourceOrigin);
    }

    private String cleanPath(String value) {
        if (!isFirstParty(value)) return null;
        String raw = URI.create(value).getRawPath();
        if (raw == null || raw.isEmpty()) return "/";
        if (!raw.matches("/[A-Za-z0-9._/-]*") || raw.contains("//")) return null;
        for (String segment : raw.split("/")) if (segment.equals(".") || segment.equals("..")) return null;
        return raw;
    }

    public boolean isApi(String value) {
        String path = cleanPath(value);
        return path != null && path.startsWith("/api/campus/");
    }

    public String assetPath(String value) {
        String path = cleanPath(value);
        if (path == null || path.equals("/api") || path.startsWith("/api/")) return null;
        return path.equals("/") ? "index.html" : path.substring(1);
    }

    public boolean isAppDocument(String value) {
        String path = cleanPath(value);
        return "/".equals(path) || "/index.html".equals(path);
    }

    public boolean validApkUrl(String value, String sha256) {
        if (!validSha256(sha256) || !isFirstParty(value)) return false;
        return value.equals(origin + "/api/campus/app-release/apk?sha=" + sha256);
    }

    public static boolean safeExternalHttps(String value) {
        try {
            URI uri = URI.create(value);
            return value.length() <= 2048 && "https".equals(uri.getScheme())
                    && uri.getHost() != null && uri.getRawUserInfo() == null
                    && (uri.getPort() == -1 || uri.getPort() == 443) && !value.matches("(?s).*[\\p{Cntrl}].*");
        } catch (RuntimeException error) { return false; }
    }

    public String notificationUrl(String value) {
        String candidate = value.startsWith("#/") ? origin + "/" + value
                : value.startsWith("/#/") ? origin + value : value;
        if (!isAppDocument(candidate) || candidate.length() > 2048)
            throw new IllegalArgumentException("Notification destination must be an app route.");
        URI uri = URI.create(candidate);
        String fragment = uri.getRawFragment();
        if (uri.getRawQuery() != null || fragment == null || !fragment.startsWith("/")
                || fragment.contains("\\") || fragment.matches("(?s).*[\\p{Cntrl}].*"))
            throw new IllegalArgumentException("Notification destination must be an app route.");
        return origin + "/#" + fragment;
    }

    public static boolean validSha256(String value) { return value != null && value.matches("[a-f0-9]{64}"); }

    public static boolean validBase64Chunk(String value) {
        return value != null && !value.isEmpty() && value.length() <= 87_384
                && value.length() % 4 == 0 && value.matches("[A-Za-z0-9+/]+={0,2}");
    }

    public static String safeFileName(String value) {
        if (value == null) throw new IllegalArgumentException("A filename is required.");
        String name = value.replaceAll("[\\p{Cntrl}/\\\\:*?\"<>|]", "_").replaceAll("^\\.+", "").trim();
        if (name.isEmpty()) name = "download";
        return name.substring(0, Math.min(name.length(), 120));
    }

    public static boolean validApkIdentity(String candidatePackage, long candidateCode, long requestedCode,
            String installedPackage, long installedCode) {
        return installedPackage.equals(candidatePackage) && candidateCode == requestedCode
                && candidateCode > installedCode && candidateCode <= 2_100_000_000L;
    }

    public static boolean sameSigners(byte[][] installed, byte[][] candidate) {
        if (installed == null || candidate == null || installed.length == 0 || installed.length != candidate.length) return false;
        boolean[] consumed = new boolean[candidate.length];
        for (byte[] signer : installed) {
            boolean found = false;
            for (int i = 0; i < candidate.length; i++) {
                if (!consumed[i] && MessageDigest.isEqual(signer, candidate[i])) { consumed[i] = true; found = true; break; }
            }
            if (!found) return false;
        }
        return true;
    }

    public static String hex(byte[] bytes) {
        StringBuilder value = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) value.append(Character.forDigit((b >>> 4) & 15, 16)).append(Character.forDigit(b & 15, 16));
        return value.toString();
    }
}
