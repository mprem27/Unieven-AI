package in.velstudents.veltechams;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** App-owned Android window. React screens and cookies live in this WebView, never Chrome. */
public final class MainActivity extends Activity implements NativeBridge.Host {
    private static final String NOTIFICATION_CHANNEL = "campus-foreground";
    private final NativePolicy policy = new NativePolicy(BuildConfig.DEPLOYMENT_ORIGIN);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ResumeTracker resume = new ResumeTracker();
    private final DocumentSession documents = new DocumentSession();
    private final SystemActionIds actionIds = new SystemActionIds();
    private int runtimeRequest, saveRequest, chooserRequest, shareRequest, settingsRequest, installerRequest;
    private WebView web;
    private NativeBridge bridge;
    private boolean destroyed, shareActive, externalBrowserActive, updateActive;
    private Consumer<Boolean> runtimePending;
    private String[] runtimePermissions;
    private volatile String saveTransfer;
    private File saveSource;
    private NativeBridge.Completion saveDone;
    private CancellationSignal saveCancellation;
    private volatile ParcelFileDescriptor saveDescriptor;
    private Runnable saveTimeout;
    private ValueCallback<Uri[]> chooserCallback;
    private WebChromeClient.FileChooserParams chooserParams;
    private Uri captureUri;
    private File captureFile, updateFile;
    private NativeBridge.Completion updateDone;
    private Runnable updateTimeout;
    private long updateSerial, chooserDocument;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        cleanCacheDirectory("captures"); cleanCacheDirectory("updates");
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            showFailure("Update Android System WebView, then reopen Veltech AMS mini."); return;
        }
        try {
            FrameLayout root = new FrameLayout(this); root.setBackgroundColor(Color.rgb(16,28,53));
            root.setOnApplyWindowInsetsListener((view,insets) -> {
                view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom()); return insets;
            });
            web = new WebView(this); web.setBackgroundColor(Color.rgb(245,247,251));
            root.addView(web,new FrameLayout.LayoutParams(-1,-1)); setContentView(root);
            WebView.setWebContentsDebuggingEnabled(false);
            WebSettings settings = web.getSettings();
            settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(false); settings.setAllowContentAccess(false);
            settings.setAllowFileAccessFromFileURLs(false); settings.setAllowUniversalAccessFromFileURLs(false);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            settings.setJavaScriptCanOpenWindowsAutomatically(false); settings.setSupportMultipleWindows(false);
            settings.setMediaPlaybackRequiresUserGesture(true); settings.setGeolocationEnabled(true);
            if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
            CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
            web.setWebViewClient(new BundledWebClient(this,policy,this::externalLink,this::documentStarted));
            web.setWebChromeClient(chromeClient());
            bridge = new NativeBridge(policy,this,getCacheDir(),documents);
            WebViewCompat.addWebMessageListener(web,"VeltechNativeBridge",java.util.Collections.singleton(policy.origin),bridge);
            web.setDownloadListener((url,userAgent,disposition,mime,length) -> Toast.makeText(this,"Use the Save or Download action in the app.",Toast.LENGTH_LONG).show());
            if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::nativeBack);
            web.loadUrl(initialUrl(getIntent()));
        } catch (Exception error) { showFailure("The bundled app could not open. Reinstall the verified current APK without clearing app data."); }
    }
    private String initialUrl(Intent intent) {
        try { if (intent.getDataString() != null) return policy.notificationUrl(intent.getDataString()); } catch (Exception ignored) {}
        return policy.origin + "/#/home";
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if (web != null && intent.getDataString() != null) {
            try { web.loadUrl(policy.notificationUrl(intent.getDataString())); } catch (Exception ignored) {}
        }
    }
    private void nativeBack() { if (web != null && web.canGoBack()) web.goBack(); else finish(); }
    @Override public void onBackPressed() { nativeBack(); }
    @Override protected void onPause() {
        resume.pause(SystemClock.elapsedRealtime(),isExternalAction());
        if (web != null) web.onPause(); CookieManager.getInstance().flush(); super.onPause();
    }
    @Override protected void onResume() {
        super.onResume(); if (web != null) web.onResume();
        ResumeTracker.Return returned = resume.resume(SystemClock.elapsedRealtime());
        if (web != null && returned.backgroundMs > 0) {
            try {
                JSONObject detail = new JSONObject().put("backgroundMs",returned.backgroundMs).put("externalAction",returned.externalAction || isExternalAction());
                web.evaluateJavascript("window.dispatchEvent(new CustomEvent('veltech:native-resume',{detail:"+detail+"}));",null);
            } catch (Exception ignored) {}
        }
        externalBrowserActive = false;
    }
    private boolean isExternalAction() { return runtimePending != null || saveTransfer != null || chooserCallback != null || shareActive || updateActive || externalBrowserActive; }
    private void externalLink(String url) {
        if (!NativePolicy.safeExternalHttps(url)) return;
        try { externalBrowserActive = true; startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)); }
        catch (Exception error) { externalBrowserActive = false; Toast.makeText(this,"No app can open this link.",Toast.LENGTH_SHORT).show(); }
    }
    private void showFailure(String message) { TextView text = new TextView(this); text.setText(message); text.setPadding(32,80,32,32); text.setTextSize(18); setContentView(text); }
    private void cleanCacheDirectory(String name) { File[] files = new File(getCacheDir(),name).listFiles(); if (files != null) for (File file : files) if (file.isFile()) file.delete(); }
    private void documentStarted() {
        documents.advance();
        if (saveTransfer != null) cancelSave(saveTransfer);
        if (chooserCallback != null) { finishActivity(chooserRequest); finishChooser(null); }
        if (runtimePending != null) { Consumer<Boolean> pending = runtimePending; runtimePending = null; runtimePermissions = null; runtimeRequest = 0; pending.accept(false); }
        failUpdate("The document changed before update approval.");
        if (bridge != null) bridge.documentChanged();
    }

    @Override public JSONObject hello() throws Exception {
        JSONObject capabilities = new JSONObject().put("download",true).put("saveFile",true).put("share",true).put("notifications",true).put("permissions",true);
        return new JSONObject().put("runtime","android-native").put("packageId",getPackageName()).put("versionName",BuildConfig.VERSION_NAME)
                .put("version",BuildConfig.VERSION_NAME).put("versionCode",BuildConfig.VERSION_CODE).put("capabilities",capabilities).put("notificationPermission",notificationState());
    }

    @Override public void saveFile(String transferId, String name, String mime, File file, NativeBridge.Completion done) {
        if (destroyed || saveTransfer != null) { done.complete(null,"A save dialog is already active."); return; }
        saveTransfer = transferId; saveSource = file; saveDone = done;
        saveTimeout = () -> cancelSave(transferId); main.postDelayed(saveTimeout,300_000);
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE,name);
            saveRequest = actionIds.next(); startActivityForResult(intent,saveRequest);
        } catch (Exception error) { completeSave(transferId,null,"The system save dialog is unavailable."); }
    }
    @Override public void cancelSave(String transferId) {
        if (transferId.equals(saveTransfer)) { finishActivity(saveRequest); completeSave(transferId,result("saved",false,"cancelled",true),null); }
    }
    private void completeSave(String transferId, JSONObject result, String error) {
        if (!transferId.equals(saveTransfer)) return;
        NativeBridge.Completion done = saveDone;
        if (saveTimeout != null) main.removeCallbacks(saveTimeout);
        if (saveCancellation != null) saveCancellation.cancel();
        if (saveDescriptor != null) try { saveDescriptor.close(); } catch (Exception ignored) {}
        saveCancellation = null; saveDescriptor = null; saveTransfer = null; saveSource = null; saveDone = null; saveRequest = 0;
        done.complete(result,error);
    }
    private void copySavedFile(Uri destination) {
        final String transfer = saveTransfer; final File source = saveSource;
        if (transfer == null) return;
        if (destination == null || !"content".equals(destination.getScheme())) { completeSave(transfer,null,"The save provider returned an invalid destination."); return; }
        if (saveTimeout != null) main.removeCallbacks(saveTimeout);
        saveTimeout = () -> completeSave(transfer,null,"The save operation timed out."); main.postDelayed(saveTimeout,120_000);
        saveCancellation = new CancellationSignal(); final CancellationSignal cancellation = saveCancellation;
        io.execute(() -> {
            try (ParcelFileDescriptor descriptor = getContentResolver().openFileDescriptor(destination,"wt",cancellation)) {
                if (descriptor == null) throw new java.io.IOException("The destination could not be opened.");
                synchronized (this) { if (!transfer.equals(saveTransfer)) return; saveDescriptor = descriptor; }
                try (FileInputStream input = new FileInputStream(source); FileOutputStream output = new FileOutputStream(descriptor.getFileDescriptor())) {
                    byte[] buffer = new byte[64*1024]; int count; long total = 0, started = SystemClock.elapsedRealtime();
                    while ((count = input.read(buffer)) != -1) {
                        if (cancellation.isCanceled() || (total += count) > NativePolicy.MAX_FILE_BYTES || SystemClock.elapsedRealtime()-started > 120_000) throw new java.io.IOException("The save operation was cancelled.");
                        output.write(buffer,0,count);
                    }
                    output.flush();
                }
                runOnUiThread(() -> completeSave(transfer,result("saved",true),null));
            } catch (Exception error) { runOnUiThread(() -> completeSave(transfer,null,"The file could not be saved. Choose a destination and try again.")); }
        });
    }

    @Override public void share(JSONObject payload, NativeBridge.Completion done) throws Exception {
        if (shareActive) throw new IllegalStateException("A share sheet is already active.");
        String title = boundedOptional(payload,"title",120), text = boundedOptional(payload,"text",8192), url = boundedOptional(payload,"url",2048);
        if (!url.isEmpty() && !NativePolicy.safeExternalHttps(url)) throw new IllegalArgumentException("Only HTTPS links can be shared.");
        if (text.isEmpty() && url.isEmpty()) throw new IllegalArgumentException("There is nothing to share.");
        Intent intent = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT,title).putExtra(Intent.EXTRA_TEXT,text+(url.isEmpty()?"":"\n"+url));
        try { shareRequest = actionIds.next(); shareActive = true; startActivityForResult(Intent.createChooser(intent,title.isEmpty()?"Share from Veltech mini":title),shareRequest); done.complete(result("shared",true),null); }
        catch (Exception error) { shareActive = false; throw new IllegalStateException("The Android share sheet is unavailable."); }
    }

    @Override public void downloadApk(JSONObject payload, NativeBridge.Completion done) throws Exception {
        if (updateActive) throw new IllegalStateException("An app update is already active.");
        String url = NativeBridge.string(payload,"url",2048), sha = NativeBridge.string(payload,"sha256",64);
        long version = NativeBridge.integer(payload,"versionCode",1,2_100_000_000);
        if (!policy.validApkUrl(url,sha)) throw new IllegalArgumentException("Use the verified first-party APK endpoint.");
        final long operation = ++updateSerial, document = documents.generation();
        updateActive = true; updateDone = done;
        updateTimeout = () -> failUpdate("The update approval timed out. Check for updates again."); main.postDelayed(updateTimeout,300_000);
        io.execute(() -> {
            try {
                File downloaded = NativeApkUpdater.download(this,policy,url,sha,version);
                runOnUiThread(() -> {
                    if (destroyed || !updateActive || operation != updateSerial || !documents.isCurrent(document)) { downloaded.delete(); return; }
                    updateFile = downloaded;
                    try {
                        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                            settingsRequest = actionIds.next();
                            startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())),settingsRequest);
                        }
                        else openInstaller();
                    } catch (Exception error) { failUpdate("Android could not open the installer approval."); }
                });
            } catch (Exception error) { runOnUiThread(() -> { if (operation == updateSerial && documents.isCurrent(document)) failUpdate(NativeBridge.safeError(error)); }); }
        });
    }
    private void openInstaller() {
        if (!updateActive || updateFile == null) return;
        try {
            Uri uri = FileProvider.getUriForFile(this,getPackageName()+".files",updateFile);
            Intent intent = new Intent(Intent.ACTION_INSTALL_PACKAGE).setDataAndType(uri,"application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).putExtra(Intent.EXTRA_RETURN_RESULT,true);
            installerRequest = actionIds.next(); startActivityForResult(intent,installerRequest);
            if (updateTimeout != null) main.removeCallbacks(updateTimeout);
            NativeBridge.Completion done = updateDone; updateDone = null;
            if (done != null) done.complete(result("installerOpened",true),null);
        } catch (Exception error) { failUpdate("The Android installer is unavailable."); }
    }
    private void failUpdate(String error) {
        updateSerial++;
        settingsRequest = 0; installerRequest = 0;
        if (updateTimeout != null) main.removeCallbacks(updateTimeout);
        if (updateFile != null) updateFile.delete(); updateFile = null; updateActive = false;
        NativeBridge.Completion done = updateDone; updateDone = null; if (done != null) done.complete(null,error);
    }

    private String notificationState() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            return getPreferences(MODE_PRIVATE).getBoolean("notifications-requested",false) ? "denied" : "default";
        return NotificationManagerCompat.from(this).areNotificationsEnabled() ? "granted" : "denied";
    }
    @Override public void notificationPermission(NativeBridge.Completion done) {
        if (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) { done.complete(result("granted",notificationState().equals("granted")),null); return; }
        getPreferences(MODE_PRIVATE).edit().putBoolean("notifications-requested",true).apply();
        requestRuntime(new String[]{Manifest.permission.POST_NOTIFICATIONS},granted -> done.complete(result("granted",granted && notificationState().equals("granted")),null));
    }
    @Override public void notifyUser(JSONObject payload, NativeBridge.Completion done) throws Exception {
        String title = NativeBridge.string(payload,"title",120), body = NativeBridge.string(payload,"body",240), tag = NativeBridge.string(payload,"tag",64);
        if (!tag.matches("[A-Za-z0-9._:-]+")) throw new IllegalArgumentException("Invalid notification tag.");
        String url = policy.notificationUrl(payload.has("url") ? NativeBridge.string(payload,"url",2048) : "#/home");
        if (!notificationState().equals("granted")) { done.complete(result("shown",false),null); return; }
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(new NotificationChannel(NOTIFICATION_CHANNEL,"Campus app alerts",NotificationManager.IMPORTANCE_DEFAULT));
        Intent intent = new Intent(this,MainActivity.class).setData(Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent destination = PendingIntent.getActivity(this,tag.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder notification = new NotificationCompat.Builder(this,NOTIFICATION_CHANNEL).setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title).setContentText(body).setContentIntent(destination).setAutoCancel(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setSilent(payload.optBoolean("silent",false));
        NotificationManagerCompat.from(this).notify(tag,1,notification.build()); done.complete(result("shown",true),null);
    }

    private void requestRuntime(String[] permissions, Consumer<Boolean> callback) {
        if (runtimePending != null) { callback.accept(false); return; }
        List<String> missing = new ArrayList<>(); for (String permission : permissions) if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) missing.add(permission);
        if (missing.isEmpty()) { callback.accept(true); return; }
        final long document = documents.generation();
        runtimePending = accepted -> callback.accept(accepted && documents.isCurrent(document)); runtimePermissions = permissions;
        try { runtimeRequest = actionIds.next(); requestPermissions(missing.toArray(new String[0]),runtimeRequest); }
        catch (Exception error) { runtimePending = null; runtimePermissions = null; runtimeRequest = 0; callback.accept(false); }
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] granted) {
        super.onRequestPermissionsResult(request,permissions,granted);
        if (request == runtimeRequest && runtimePending != null) {
            Consumer<Boolean> done = runtimePending; boolean accepted = true;
            for (String permission : runtimePermissions) if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) accepted = false;
            runtimePending = null; runtimePermissions = null; runtimeRequest = 0; done.accept(accepted);
        }
    }
    private boolean trustedPage() { return web != null && policy.isAppDocument(web.getUrl()); }
    private WebChromeClient chromeClient() {
        return new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                if (!trustedPage() || !policy.acceptBridge(request.getOrigin().toString(),true)) { request.deny(); return; }
                List<String> permissions = new ArrayList<>(); List<String> resources = new ArrayList<>();
                for (String resource : request.getResources()) {
                    if (resource.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) { permissions.add(Manifest.permission.CAMERA); resources.add(resource); }
                    else if (resource.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { permissions.add(Manifest.permission.RECORD_AUDIO); resources.add(resource); }
                    else { request.deny(); return; }
                }
                if (permissions.isEmpty()) { request.deny(); return; }
                requestRuntime(permissions.toArray(new String[0]),accepted -> {
                    try { if (accepted && trustedPage()) request.grant(resources.toArray(new String[0])); else request.deny(); } catch (Exception ignored) {}
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (!trustedPage() || !policy.acceptBridge(origin,true)) { callback.invoke(origin,false,false); return; }
                final long document = documents.generation();
                requestRuntime(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},accepted ->
                        callback.invoke(origin,documents.isCurrent(document) && trustedPage()
                                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED,false));
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (!trustedPage() || chooserCallback != null) { callback.onReceiveValue(null); return true; }
                chooserCallback = callback; chooserParams = params; chooserDocument = documents.generation();
                if (params.isCaptureEnabled()) {
                    String type = chooserMime();
                    String[] permissions = type.startsWith("video/") ? new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO} : new String[]{Manifest.permission.CAMERA};
                    requestRuntime(permissions,accepted -> { if (accepted && documents.isCurrent(chooserDocument)) launchFileChooser(true); else finishChooser(null); });
                } else launchFileChooser(false);
                return true;
            }
        };
    }
    private String chooserMime() {
        if (chooserParams != null) for (String type : chooserParams.getAcceptTypes()) if (type != null && type.matches("[A-Za-z0-9.+*-]+/[A-Za-z0-9.+*-]+")) return type;
        return "*/*";
    }
    private void launchFileChooser(boolean capture) {
        if (chooserCallback == null || !documents.isCurrent(chooserDocument)) { finishChooser(null); return; }
        try {
            String type = chooserMime(); Intent intent;
            if (capture && (type.startsWith("image/") || type.startsWith("video/"))) {
                boolean video = type.startsWith("video/");
                File directory = new File(getCacheDir(),"captures"); if (!directory.isDirectory() && !directory.mkdirs()) throw new java.io.IOException();
                captureFile = File.createTempFile("capture-",video?".mp4":".jpg",directory);
                captureUri = FileProvider.getUriForFile(this,getPackageName()+".files",captureFile);
                intent = new Intent(video?MediaStore.ACTION_VIDEO_CAPTURE:MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT,captureUri)
                        .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.setClipData(ClipData.newRawUri("capture",captureUri));
            } else {
                intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(type)
                        .putExtra(Intent.EXTRA_ALLOW_MULTIPLE,chooserParams != null && chooserParams.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);
            }
            chooserRequest = actionIds.next(); startActivityForResult(intent,chooserRequest);
        } catch (Exception error) { finishChooser(null); }
    }
    private void finishChooser(Uri[] values) {
        if (!documents.isCurrent(chooserDocument)) values = null;
        ValueCallback<Uri[]> done = chooserCallback; chooserCallback = null; chooserParams = null; captureUri = null; chooserRequest = 0;
        if (values == null && captureFile != null) captureFile.delete(); captureFile = null;
        if (done != null) done.onReceiveValue(values);
    }
    @Override protected void onActivityResult(int request, int resultCode, Intent data) {
        super.onActivityResult(request,resultCode,data);
        if (request == saveRequest && saveTransfer != null) {
            if (resultCode == RESULT_OK && data != null) copySavedFile(data.getData()); else completeSave(saveTransfer,result("saved",false,"cancelled",true),null);
        } else if (request == chooserRequest && chooserCallback != null) {
            List<Uri> selected = new ArrayList<>();
            if (resultCode == RESULT_OK) {
                if (captureUri != null) selected.add(captureUri);
                else if (data != null && data.getClipData() != null) { ClipData clips = data.getClipData(); for (int i=0;i<Math.min(10,clips.getItemCount());i++) if ("content".equals(clips.getItemAt(i).getUri().getScheme())) selected.add(clips.getItemAt(i).getUri()); }
                else if (data != null && data.getData() != null && "content".equals(data.getData().getScheme())) selected.add(data.getData());
            }
            finishChooser(selected.isEmpty()?null:selected.toArray(new Uri[0]));
        } else if (request == shareRequest && shareActive) { shareActive = false; shareRequest = 0; }
        else if (request == settingsRequest && updateActive) {
            settingsRequest = 0;
            if (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()) openInstaller(); else failUpdate("Android did not allow this app to request installation.");
        } else if (request == installerRequest && updateActive) failUpdate("The installer closed.");
    }
    private static String boundedOptional(JSONObject value, String key, int max) throws Exception { return value.has(key) && !value.isNull(key) && !"".equals(value.opt(key)) ? NativeBridge.string(value,key,max) : ""; }
    private static JSONObject result(Object... values) { JSONObject object = new JSONObject(); try { for (int i=0;i<values.length;i+=2) object.put((String)values[i],values[i+1]); } catch (Exception ignored) {} return object; }
    @Override protected void onDestroy() {
        destroyed = true;
        documents.close();
        if (saveTransfer != null) completeSave(saveTransfer,result("saved",false,"cancelled",true),null);
        if (chooserCallback != null) finishChooser(null);
        if (runtimePending != null) { Consumer<Boolean> pending = runtimePending; runtimePending = null; pending.accept(false); }
        failUpdate("The app closed before update approval.");
        if (bridge != null) bridge.close();
        main.removeCallbacksAndMessages(null); io.shutdownNow();
        if (web != null) { web.stopLoading(); WebViewCompat.removeWebMessageListener(web,"VeltechNativeBridge"); web.destroy(); }
        super.onDestroy();
    }
}
