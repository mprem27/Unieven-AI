import {readFile,readdir,lstat,mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {APP_ICON_192,APP_ICON_512,APP_LOGO} from '../shared/app-branding.mjs';

export function assetsDigest(files){
 const hash=createHash('sha256');
 for(const [name,body] of [...files].sort(([a],[b])=>a.localeCompare(b,'en'))){hash.update(name+'\0');hash.update(createHash('sha256').update(body).digest());}
 return hash.digest('hex');
}

/** Read a finite, link-free build snapshot. API paths can never become assets. */
export async function localWebResources(config,directory){
 const root=path.resolve(directory),files=new Map();let total=0;
 if(!(await lstat(root)).isDirectory() || (await lstat(root)).isSymbolicLink())throw new Error('Local web build must be a real directory, not a symbolic link.');
 async function visit(relative=''){
  for(const item of await readdir(path.join(root,relative),{withFileTypes:true})){
   const name=relative?`${relative}/${item.name}`:item.name;
   if(!/^[A-Za-z0-9._/-]+$/.test(name) || name.split('/').some(part=>part==='.' || part==='..'))throw new Error(`Unsafe asset path: ${name}`);
   const info=await lstat(path.join(root,name));if(info.isSymbolicLink())throw new Error(`Symbolic links are forbidden in packaged assets: ${name}`);
   if(name==='api' || name.startsWith('api/'))throw new Error('The local web build must not contain API paths.');
   if(info.isDirectory()){await visit(name);continue;}
   if(!info.isFile() || info.size>8*1024*1024)throw new Error(`Invalid or oversized packaged asset: ${name}`);
   total+=info.size;if(total>50*1024*1024 || files.size>=4096)throw new Error('The local frontend build exceeds the packaged asset limit.');
   files.set(name,await readFile(path.join(root,name)));
  }
 }
 await visit();
 for(const name of ['index.html','app-build.json',APP_LOGO.slice(1),APP_ICON_192.slice(1),APP_ICON_512.slice(1)])if(!files.has(name))throw new Error(`Missing packaged frontend asset: ${name}. Run npm --prefix frontend run build first.`);
 let metadata;try{metadata=JSON.parse(files.get('app-build.json').toString('utf8'));}catch{throw new Error('Invalid app-build.json metadata.');}
 for(const [key,value] of Object.entries({version:config.versionName,logo:APP_LOGO,icon192:APP_ICON_192,icon512:APP_ICON_512}))if(metadata[key]!==value)throw new Error(`Frontend build metadata ${key} does not match this Android release. Rebuild the frontend.`);
 const html=files.get('index.html').toString('utf8');if(!/<!doctype html/i.test(html))throw new Error('The local index.html is not a built HTML document.');
 for(const match of html.matchAll(/(?:src|href)=["']([^"']+)["']/g)){
  const url=match[1];if(url.startsWith('#') || url.startsWith('data:'))continue;
  if(!url.startsWith('/') || url.startsWith('//'))throw new Error('The bundled entry document must reference first-party absolute asset paths.');
  const name=url.split(/[?#]/)[0].slice(1);if(!files.has(name))throw new Error(`Missing referenced frontend asset: ${name}`);
 }
 const icon=files.get(APP_ICON_512.slice(1));if(icon.length<24 || icon.subarray(0,8).toString('hex')!=='89504e470d0a1a0a' || icon.readUInt32BE(16)<512 || icon.readUInt32BE(20)<512)throw new Error('Current launcher icon must be a PNG of at least 512 by 512 pixels.');
 return {files,metadata,sha256:assetsDigest(files)};
}

export async function writeWebResources(resources,target){
 for(const [name,body] of resources.files){const file=path.join(target,'app/src/main/assets/web',name);await mkdir(path.dirname(file),{recursive:true});await writeFile(file,body);}
 await writeFile(path.join(target,'app/src/main/assets/asset-paths.txt'),[...resources.files.keys()].sort().join('\n')+'\n');
}
