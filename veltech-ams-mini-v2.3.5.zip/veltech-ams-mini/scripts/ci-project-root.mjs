import {appendFile, lstat, readFile, readdir, realpath} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

const supportedRoots = ['.', 'veltech-ams-mini'];
const packages = [
  ['', 'veltech-ams-mini'],
  ['frontend', 'veltech-ams-mini-frontend'],
  ['services/campus', 'veltech-ams-mini-api'],
  ['android', 'veltech-ams-mini-android'],
];

async function checkedFile(directory, relative) {
  const file = path.join(directory, relative);
  let info;
  try { info = await lstat(file); }
  catch (error) {
    if (error.code === 'ENOENT' || error.code === 'ENOTDIR') throw new Error(`${relative} is missing`);
    throw new Error(`${relative} cannot be read`);
  }
  if (!info.isFile() || info.isSymbolicLink()) throw new Error(`${relative} must be a regular source file, not a symlink`);
  if (!(await realpath(file)).startsWith(`${directory}${path.sep}`)) throw new Error(`${relative} resolves outside the source directory`);
  return file;
}

async function jsonFile(directory, relative) {
  const file = await checkedFile(directory, relative);
  try {
    const parsed = JSON.parse(await readFile(file, 'utf8'));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error();
    return parsed;
  } catch { throw new Error(`${relative} must contain valid JSON object data`); }
}

async function validateSource(workspace, source) {
  const directory = path.join(workspace, source);
  const info = await lstat(directory);
  if (!info.isDirectory() || info.isSymbolicLink() || (await realpath(directory)) !== directory) {
    throw new Error('source must be a directory inside the checkout, not a symlink');
  }
  for (const [relative, name] of packages) {
    const manifestPath = path.posix.join(relative, 'package.json');
    const manifest = await jsonFile(directory, manifestPath);
    if (manifest.name !== name) throw new Error(`${manifestPath} must identify ${name}`);
    if (relative) {
      const lockPath = `${relative}/package-lock.json`;
      const lock = await jsonFile(directory, lockPath);
      if (lock.name !== name || lock.packages?.['']?.name !== name || !(lock.lockfileVersion >= 2)) {
        throw new Error(`${lockPath} must match ${manifestPath} and use a current npm lock format`);
      }
    }
  }
  await checkedFile(directory, 'services/academic/requirements.txt');
}

export async function resolveProjectRoot(workspace) {
  let checkout;
  try { checkout = await realpath(workspace); }
  catch { throw new Error('The GitHub workspace directory does not exist. Check out the complete source first.'); }
  const valid = [], problems = [];
  for (const source of supportedRoots) {
    try { await validateSource(checkout, source); valid.push(source); }
    catch (error) {
      problems.push(`${source}/: ${error.code === 'ENOENT' ? 'source directory is missing' : error.message}`);
    }
  }
  if (valid.length > 1) throw new Error('Ambiguous source checkout: both repository root and veltech-ams-mini/ contain complete source. Keep one source tree before building.');
  if (valid.length === 1) return valid[0];
  const zipOnly = (await readdir(checkout)).some(name => /\.zip$/i.test(name));
  throw new Error(`${zipOnly ? 'ZIP-only or incomplete delivery checkout. ' : ''}Cannot find complete source at repository root or veltech-ams-mini/. Extract and commit the complete source, including manifests and lockfiles; GitHub Actions does not unzip download artifacts. ${problems.join('; ')}`);
}

export async function main(argv = process.argv.slice(2)) {
  if (argv.length) throw new Error('This resolver does not accept source-directory arguments. Usage: node scripts/ci-project-root.mjs');
  const source = await resolveProjectRoot(process.env.GITHUB_WORKSPACE || process.cwd());
  // The only possible values are constants above, never checkout filenames or
  // operator input. Both shell working directories and action cache paths use it.
  if (process.env.GITHUB_OUTPUT) await appendFile(process.env.GITHUB_OUTPUT, `source=${source}\n`);
  console.log(JSON.stringify({source}));
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch(error => { console.error(`CI source resolution stopped: ${error.message}`); process.exitCode = 1; });
}
