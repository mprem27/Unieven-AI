import {APP_ICON_512} from '../shared/app-branding.mjs';
import {readFile,writeFile,mkdir,rm,rename,copyFile,cp,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {androidRoot,repositoryRoot,projectDirectory,readConfig,argumentsFor,configDigest,GRADLE_SHA256,GRADLE_VERSION} from './android-config.mjs';
import {localWebResources,writeWebResources} from './android-native-assets.mjs';
export {localWebResources} from './android-native-assets.mjs';
export const WRAPPER_SHA256='2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046';

export async function generateProject(config,target,resources){
 const wrapper=await readFile(path.join(androidRoot,'gradle/gradle-wrapper.jar'));
 if(createHash('sha256').update(wrapper).digest('hex')!==WRAPPER_SHA256)throw new Error('Gradle wrapper checksum mismatch. Restore the official wrapper before building.');
 if(!resources?.files || resources.metadata.version!==config.versionName)throw new Error('Use a validated local frontend build for native packaging.');
 await mkdir(target,{recursive:true});await cp(path.join(androidRoot,'native-template'),target,{recursive:true});
 async function replace(directory){for(const entry of await readdir(directory,{withFileTypes:true})){const file=path.join(directory,entry.name);if(entry.isDirectory())await replace(file);else if(/\.(?:java|gradle|xml)$/.test(entry.name)){
  const source=await readFile(file,'utf8');await writeFile(file,source.replaceAll('__PACKAGE__',config.packageId).replaceAll('__ORIGIN__',config.deploymentUrl).replaceAll('__VERSION_NAME__',config.versionName).replaceAll('__VERSION_CODE__',String(config.versionCode)).replaceAll('__APP_NAME__',config.appName).replaceAll('__LAUNCHER_NAME__',config.launcherName));
 }}}
 await replace(target);
 // The source namespace remains stable for testability; applicationId retains the owner's identity.
 await writeWebResources(resources,target);
 await mkdir(path.join(target,'app/src/main/res/drawable-nodpi'),{recursive:true});await writeFile(path.join(target,'app/src/main/res/drawable-nodpi/ic_launcher.png'),resources.files.get(APP_ICON_512.slice(1)));
 await mkdir(path.join(target,'gradle/wrapper'),{recursive:true});
 await copyFile(path.join(androidRoot,'gradle/gradle-wrapper.jar'),path.join(target,'gradle/wrapper/gradle-wrapper.jar'));
 await writeFile(path.join(target,'gradle/wrapper/gradle-wrapper.properties'),`distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip\nnetworkTimeout=20000\nvalidateDistributionUrl=true\ndistributionSha256Sum=${GRADLE_SHA256}\n`);
 await writeFile(path.join(target,'velstudents-build.json'),JSON.stringify({runtime:'android-native',configDigest:configDigest(config),wrapperSha256:WRAPPER_SHA256,deploymentUrl:config.deploymentUrl,webVersion:resources.metadata.version,assetSha256:resources.sha256},null,2)+'\n');
}

export async function main(argv=process.argv.slice(2)){
 const options=argumentsFor(argv,{'--config':'value','--local-web':'value','--dry-run':'flag','--help':'flag'});
 if(options['--help']){console.log('Usage: node scripts/android-prepare.mjs [--config path] [--local-web frontend/dist] [--dry-run]\nPackages the validated local frontend build into a standalone native Android project. No live website or Digital Asset Links required.');return;}
 const config=await readConfig(options['--config']);const localWeb=path.resolve(repositoryRoot,options['--local-web'] || 'frontend/dist');
 if(options['--dry-run']){console.log(JSON.stringify({status:'configuration-valid',runtime:'android-native',deploymentUrl:config.deploymentUrl,launchUrl:`${config.deploymentUrl}/#/home`,localWeb,output:projectDirectory,packageId:config.packageId,note:'No network, Android project, key, or APK created.'},null,2));return;}
 const resources=await localWebResources(config,localWeb),staging=path.join(androidRoot,`.generated-${process.pid}`);
 try{await generateProject(config,staging,resources);await rm(projectDirectory,{recursive:true,force:true});await rename(staging,projectDirectory);}finally{await rm(staging,{recursive:true,force:true});}
 console.log(`Generated standalone native project: ${projectDirectory}\nBundled web version ${resources.metadata.version}; assets SHA-256 ${resources.sha256}. Build with the retained private release key.`);
}
if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href)main().catch(error=>{console.error(`Android preparation stopped: ${error.message}`);process.exitCode=1;});
