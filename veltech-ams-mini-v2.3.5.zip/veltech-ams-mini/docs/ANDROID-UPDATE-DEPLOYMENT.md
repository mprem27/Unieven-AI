# Android and web update deployment

Current release: [2.3.5 changes and rollout checklist](RELEASE-v2.3.5.md), package `in.velstudents.veltechams`, Android 20307. The APK bundles React screens in a native Android Activity using Android System WebView. Website/PWA and APK deployment are separate; the existing AWS/Cloudflare backend and same-origin HTTPS API remain in place.

Keep the original signing key outside source/export archives. Android updates require the same certificate and a higher versionCode. Earlier public-domain evidence listed a different certificate from the workspace key; the inaccessible older Actions APK was not inspected. Compare the actual distributed APK's certificate before rollout and use its original key if needed. Never force uninstall or a data reset to hide a mismatch.

## Build and prepare

Follow [the Windows Android guide](ANDROID.md), or run **Build signed Android release** using the [existing signing secrets](GITHUB.md). The workflow artifact includes `public-release/release.json` and a checksum-named APK; an Actions artifact is not a public student link. Local preparation uses the production frontend:

```powershell
npm --prefix frontend ci
npm --prefix frontend run build
npm --prefix android ci
node scripts/android-prepare.mjs --config android/config.release.json --local-web frontend/dist
node scripts/android-build.mjs --config android/config.release.json
node scripts/publish-android-release.mjs --apk=android/out/veltech-ams-mini-release.apk --receipt=android/out/signing-receipt.json --out=app-releases --notes="Native Android 2.3.5"
```

The build checks bundled version/artwork, APK identity/signature and alignment. It does not require live domain availability or association. `--require-domain-association` is an optional explicit gate. Keep the public receipt/checksum with the release; no private signing material is copied.

## Manual AWS / Cloudflare rollout

1. Back up existing databases, media, `.private` configuration and keys. Keep the same Compose project, database profile, volumes, cookie/encryption/VAPID keys and HTTPS origin. Do not run `down -v` or regenerate keys. Windows operators continue with Docker Desktop/PowerShell; no Ubuntu installation is required.
2. Deploy source/frontend/API through the same reviewed AWS Compose process. Retain your production env file and PostgreSQL override if used. A typical existing production command is:

   ```powershell
   docker compose --env-file .env.production -f compose.production.yaml up -d --build academic campus
   ```

   Keep the academic worker private and `/api/campus/*` on the same HTTPS hostname with existing secure cookies/origin checks/TLS.
3. Copy the verified APK **first**, then `release.json`, into the persistent release directory shared by all campus replicas. For the existing media mount, container-visible settings remain:

   ```dotenv
   CAMPUS_PUBLIC_URL=https://app.veltech-mini-ams.me
   CAMPUS_ORIGINS=https://app.veltech-mini-ams.me
   CAMPUS_COOKIE_SECURE=true
   CAMPUS_APK_DIRECTORY=/app/media/app-releases
   CAMPUS_ANDROID_PACKAGE_ID=in.velstudents.veltechams
   ```

   For a bind mount such as `/srv/veltech/app-releases`, mount it read-only and set `CAMPUS_APK_DIRECTORY` to its **container** path. Preserve old SHA-named APKs until rollout is checked. The server reads the manifest on each request; replace it atomically on later releases.
4. Bypass Cloudflare caching/challenge substitution for public `/api/campus/app-release*` routes. Preserve query strings, JSON/APK types, attachment disposition, no-store and nosniff. Do not rewrite API errors to `index.html`. Private account/academic APIs retain authentication and authorization.
5. Verify metadata reports available, version 2.3.5/code 20307 and the expected package/certificate/hash. Download its exact pinned `url`, compare SHA-256 and confirm `latest.apk` serves an APK without external redirects. A stale pinned checksum must return 409 after the release changes. Public metadata/downloads work before sign-in and expose no student data.
6. If maintaining Digital Asset Links, publish public `/.well-known/assetlinks.json` with the actual certificate and check HTTP 200/application/json without redirects/challenges. Association is separate from native screen hosting. Never publish signing private keys.
7. Test a phone's install/same-key update, one-time TWA migration login, later native session/data retention, file save/cancel, sharing and granted/denied permissions. Signature/HTTP checks alone do not establish phone acceptance or live AMS behavior.

Student links:

- `https://app.veltech-mini-ams.me/#/install`
- `https://app.veltech-mini-ams.me/api/campus/app-release/latest.apk`

The browser saves the own-domain attachment; the native updater verifies its pinned download and opens Android's installer. Android controls source approval and Install/Update warnings. No silent installation or OS-warning bypass is provided. See [installation and sharing](ANDROID-INSTALL-SHARE.md).

## Keep the update paths separate

The native APK does not register the website service worker or offer PWA installation. Its static UI changes with a signed APK update; `/api/*` remains live network traffic. A reload reopens the bundled version without clearing cookies, IndexedDB or saved records. Native foreground alerts respect permission/preferences; background push while closed is not promised. Release checks run for an authenticated account while visible/online, sharing in-flight requests and a 15-minute successful-check cooldown. **Later · 24 hours** defers that release for the current account.

Browser/PWA updates retain the service-worker lifecycle and **Later** reminder. Accepting an update activates the waiting worker and reloads when ready; declining does not reload. **Refresh app assets** applies to the browser/PWA, preserves sessions/private caches/downloads and never resets or reinstalls Android.

Project downloads may be published only in [vtu26418-design/Clinical](https://github.com/vtu26418-design/Clinical). Repository write access is currently unavailable; no GitHub publication or production AWS/Cloudflare deployment is claimed. Student APK delivery remains on the app's own domain after the operator publishes it there.
