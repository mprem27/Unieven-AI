# Setup, update and install

This is the complete combined **veltech-ams-mini 2.3.5** application. Use Docker Desktop with Linux containers and PowerShell on Windows; no Ubuntu distribution or Bash setup script is required. Node.js 24 is needed only for local frontend development/builds. New Docker installations default to PostgreSQL/FerretDB; existing Atlas installations retain their profile. See [Windows setup](V2-UPGRADE.md) and [the current release checklist](RELEASE-v2.3.5.md).

## Existing Windows installation

1. Stop the application with your existing `Stop.ps1`. Back up your existing `.private` directory and database/media data privately.
2. Extract the source ZIP into a new directory. Copy the existing `.private` directory into that new project directory. Preserve all keys, Atlas database names and SMTP settings. Never upload `.private` or production env files to GitHub.
3. In PowerShell, open the extracted directory that contains `package.json`, `Start.ps1` and `compose.yaml`:

```powershell
Set-Location P:\Intenship\veltech-ams-mini
docker compose -f compose.yaml build
powershell -ExecutionPolicy Bypass -File .\Start.ps1
```

The build command updates both service images; `Start.ps1` starts them and checks health. Open the localhost URL printed by the script. Do not delete volumes or generate new encryption keys for an upgrade. Rebuild the private academic service as well as the frontend/campus service to use the faster combined workspace endpoint.

## Fresh Windows setup

```powershell
Set-Location P:\Intenship\veltech-ams-mini
powershell -ExecutionPolicy Bypass -File .\Setup.ps1
powershell -ExecutionPolicy Bypass -File .\Start.ps1
```

Setup keeps generated configuration in `.private`; new installations use the supplied PostgreSQL/FerretDB Docker profile. For a new Atlas installation only, use `Setup.ps1 -Database Atlas` and configure its private network access. Keep an existing installation's database profile and credentials unchanged. For React development, `npm run setup`, then `npm run dev:api` and `npm run dev` in separate PowerShell windows. A frontend-only preview still needs the combined API for real accounts/source access.

## Deploy the complete app

Follow [HOSTING.md](HOSTING.md) for a Docker host with an HTTPS tunnel or [deployment.md](deployment.md) for Nginx/TLS and multiple campus replicas. The web ZIP is a production frontend build; live sign-in requires the backend and `/api/campus` routing at the same public origin.

Set these in the existing **private** files, using your actual values:

| File | Values to configure |
| --- | --- |
| `.private/campus.env` | `MONGODB_URI`, persistent `CAMPUS_LINK_KEY`, matching `CAMPUS_SERVICE_KEY`, exact `CAMPUS_ORIGINS=https://your-domain`, `CAMPUS_COOKIE_SECURE=true`, `ACADEMIC_API_URL=http://academic:8000/api/v1`, real SMTP sender/settings |
| `.private/academic.env` | Atlas `MONGO_URI`, original `MONGO_DB_NAME`, persistent `JWT_SECRET` and source encryption keys, matching `CAMPUS_SERVICE_KEY` |
| `.env.production` | Real DNS hostname and certificate directory when using the production Nginx topology |

Do not enable secure cookies on plain localhost HTTP. Do enable them for hosted HTTPS. Keep one academic worker because university browser sessions are process-local. Campus replicas can share durable Mongo sessions and media under the documented same-host configuration. Existing queue limits prevent a burst of students from opening unlimited AMS sessions.

Configure SMTP using [EMAIL-SMTP.md](EMAIL-SMTP.md). Put credentials only in private configuration. Test your real sender and password recovery after deployment; free provider limits and outbound SMTP availability depend on the chosen host. Mailpit is only for local development.

Before releasing the URL, check public health with the supplied production checker, then test your own login, reload, logout, one source sync, recovery email, downloads and a phone install. Keep academic and database services private. The public Android release origin is `https://app.veltech-mini-ams.me`; private provider credentials are excluded from delivery.

## Install on a phone

For the Android APK, share **https://app.veltech-mini-ams.me/#/install** after publishing the verified release. Android controls source approval and Install/Update. The native Activity displays bundled React screens using Android System WebView; it does not launch Chrome for its main screen. Follow [ANDROID.md](ANDROID.md) for local build/signing and [ANDROID-UPDATE-DEPLOYMENT.md](ANDROID-UPDATE-DEPLOYMENT.md) for same-origin AWS/Cloudflare delivery. Version is 2.3.5/20307, package `in.velstudents.veltechams`.

The optional browser/PWA can be installed separately after hosting the complete app at HTTPS:

- Android Chrome: open the URL, then **Install app** or **Add to Home screen** in the browser menu.
- iPhone Safari: open the URL, tap **Share → Add to Home Screen**.

The PWA uses the existing logo, standalone display and service worker. Sign-in uses the existing rolling HttpOnly session; refresh and app updates restore a valid session. Do not clear browser/app site data if you want to retain that session. Actual logout, expiry or revoked sessions require sign-in again. AMS may separately request official verification when its upstream session expires.

The native APK offers no PWA installation and does not register the website service worker. Its static UI updates through a same-key signed APK, while `/api/*` keeps using the existing backend. The first TWA-to-native update may require one login because browser/WebView storage is separate; later native updates preserve cookies and saved data. Keep the original signing key private. Domain association is an optional separate check, not a local-packaging prerequisite. Never clear app data or uninstall for a routine update.

## What changed

The welcome starts after verified login; Wait for all sections overrides early exit; Open Home allows continued use while sync runs. The main academic workspace now needs one private request, overlapping reads are shared, and transient saved-session failures receive one bounded retry. Assessment marks retain their tables/exports without graphs; semester/final-result graphs remain.

See [VERIFICATION.md](VERIFICATION.md) for the recorded checks and their limits. The college's availability and free-host resource limits remain outside the app's control; an unavailable source is shown accurately instead of inventing records.
