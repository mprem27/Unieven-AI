# Standalone Android app, web update and launch behavior

The owner explicitly wants an APK that opens as its own app rather than Chrome/PWA, with matching website changes, consistent current logo and launch animation on fresh openings. The owner has already delegated professional implementation choices and requested execution without repeated approval. This extends the completed2.3.4 source; retain all student/faculty/admin features and source-data/auth fences.

## Chosen architecture

Replace the default browser-based TWA wrapper with a native Android Activity hosting the packaged React screens in Android System WebView. The APK bundles the production frontend, owns its navigation/back/keyboard/permissions/download actions and does not launch Chrome for its primary screen. This is a hybrid native app using the existing React UI, not a rewrite into native widgets. The same React source builds the website/PWA, so UI and logo changes apply to both.

Serve bundled static GET resources through the configured HTTPS first-party origin using a restricted WebView asset handler. Network API calls continue to the user's existing same-origin HTTPS backend, preserving HttpOnly cookies and strict origin/CSRF rules. Do not weaken server cookies/CORS, bypass TLS errors, use file:// for the UI, expose addJavascriptInterface to every frame, or navigate untrusted content inside the privileged WebView. Offline saved records use the existing owner-bound encrypted store. Native WebView storage persists across later signed APK updates; the first migration from a TWA/Chrome install may need one app login because browser storage is separate.

Keep `in.velstudents.veltechams`, owner-held signing identity and deployed origin `https://app.veltech-mini-ams.me`. Build display2.3.5 and Android20307. Compile with the existing pinned Gradle8.11.1/AGP8.9.1/JDK21/platform36/build-tools36.1.0, minSDK24. Publish project downloads only via vtu26418-design/Clinical; actual repository access remains an external prerequisite if GitHub denies writes. Never substitute another repository/temporary host.

## Native boundaries and interface

Use AndroidX WebKit's origin-restricted WebMessageListener `VeltechNativeBridge` for main-frame messages only, added before loading. Do not use an unrestricted JavaScript interface. Message request `{id,type,payload}`; reply `{id,ok,result}` or `{id,ok:false,error}` via the caller's reply proxy. Frontend owns bounded promises and can fall back to normal browser features when no native bridge exists.

- `hello`: authoritative runtime/package/version/capabilities/notification permission.
- `beginFile`: `{name,mimeType,bytes,sha256}`; returns transferId. Maximum15MiB, one active transfer; app-private temporary storage.
- `appendFile`: `{transferId,index,base64}`; sequential chunks of at most64KiB decoded, bounded message size; no arbitrary paths.
- `finishFile`: `{transferId}`; verify count/checksum then Android Create Document picker; reply after save/cancel. Delete task temporary data on completion/cancel/destruction.
- `cancelFile`: `{transferId}`; idempotent cleanup.
- `share`: bounded `{title,text,url}`; user-initiated Android share sheet, safe HTTPS URL only.
- `downloadApk`: `{url,sha256,versionCode}`; own-origin pinned APK endpoint only. Download on a worker with finite size/time limits, reject redirects, verify SHA/package/version/signing identity, then invoke Android's explicit installer approval. Never silently install or clear user data.
- `notificationPermission`: user-initiated permission request; return granted boolean.
- `notify`: generic bounded `{title,body,tag,url,silent}`; respect OS permission and caller preferences, destination restricted to app hash routes. No new background-push guarantee.

Native camera, microphone and geolocation prompts are limited to first-party requests and Android runtime permissions; file chooser uses system selection/capture and does not grant arbitrary filesystem access. External HTTPS links open externally without forwarding app credentials. SSL errors cancel.

## Launch and app updates

Each fresh document/cold app opening shows the approved whole-logo animation. Ordinary route/tab clicks do not restart it. Android background return after at least30seconds can replay via `veltech:native-resume` with `{backgroundMs,externalAction}`; short file-picker/permission returns must not interrupt work. Disabled opening-animation and reduced-motion preferences remain honored. Keep the same logo design/colours, use2.3.5 versioned artwork paths and avoid excessive glow. Add restrained motion/press feedback that does not remount account providers or reset form state.

Native APK install/update and web/PWA update are separate actions. Native uses Android download/install, hides browser/PWA install prompts and never registers the website service worker over bundled assets. PWA updates remain opt-in and do not wipe sessions/downloads. A declined update stays declined for its existing reminder interval. Every build emits `app-build.json` with version and current artwork URLs; native packaging checks it against release configuration, so an APK cannot accidentally bundle an older frontend.

## GitHub workflows

Audit confirmed failure conditions: Android preparation depends on already deployed web assets; initial signing/domain association can block otherwise valid compilation; workflows assume the source is at repository root. Build from local locked frontend output, check signing secrets early with useful errors, and make domain association an optional operator check rather than a prerequisite for the native screen. Resolve only supported root or `veltech-ams-mini/` layouts; explicitly explain that ZIP-only delivery branches are not source checkouts. Do not hide real test/signing failures or change GitHub permissions in code.

## Validation

Meaningful RED→GREEN regressions for launch reopening, native transport/download boundaries, install-kind distinction and workflow source layout. Java policy unit tests, native compile and actual signed binary/package/signature/alignment inspection. Full existing application/academic/helper suites, production web build and browser flows with fictional records. A real device/emulator and live AMS check may remain unverified; report those limits plainly. Preserve private keys/configuration/volumes and original checkouts.
