# Student identity, regulation and source sync update

The owner has delegated professional UI choices and requested execution without another design approval cycle. Improve the existing combined application rather than replacing its navigation or copying Home of VelTech. Its screenshots are a workflow reference: readable identity, immediate academic access, clear subject records.

Home must show the complete official name or university ID at the top, retain the student photograph, and show a compact set of genuinely available college fields. Social display names must not change college identity. Missing values must remain unavailable rather than become fabricated profile data. Readable wrapping at 320–430 px matters more than dense decoration.

Published AMS CGPA/percentage take priority. Derived calculations must match an explicitly identified official regulation and programme, with source/estimate distinctions preserved. Do not infer a regulation from an admission year or silently apply a universal grade scale. Existing official-source research in docs/ACADEMIC-REGULATIONS.md remains authoritative evidence.

First university sign-in uses the official challenge when required and starts sync. A verified returning account uses the app's password verifier and durable app session. Campus authentication is distinct from the expiring university session. Active upstream sessions can refresh data; expired/missing upstream sessions need explicit verification for fresh university data. Never solve a CAPTCHA automatically, claim to detect unseen AMS changes, replay credentials, or force a source reconnect on every app refresh.

Keep the current approved hybrid logo design and college/Attendance colour scheme. Audit all app-brand placements, static/reduced-motion images, PWA/native/notification icons and cached asset paths. Version asset URLs so an old immutable browser cache cannot keep the previous logo. Animate the complete readable emblem without distorting the official centre. Institutional PDF emblems remain institutional marks.

Use the current React/FastAPI/campus API architecture and Windows Docker workflow. Bump display version to 2.3.4 and Android build code to 20306. Preserve user data, encryption keys, original repositories, signing identity and database volumes. Package the full clean source, compiled web app, signed APK and upgrade guide. Publish download files only to vtu26418-design/Clinical; any confirmed write-access blocker must be reported honestly without switching repositories or public file hosts.

Approach chosen by the implementer under the owner's delegation: targeted identity/source-state corrections and versioned branding. A full navigation redesign would unnecessarily change the accepted workflow; storing/replaying university passwords to hide verification would be inappropriate and is excluded.
