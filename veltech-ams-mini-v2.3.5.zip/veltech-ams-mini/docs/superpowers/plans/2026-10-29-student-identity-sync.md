# Student identity and sync implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Deliver clear official student identity, correctly scoped academic summaries, predictable returning login and consistent current branding.

**Architecture:** Preserve existing account/source boundaries. Separate the Home view-model, regulation calculations and portal authentication tasks; coordinate shared interfaces before integration. Reuse the existing logo artwork with fresh versioned public asset names.

**Tech Stack:** React 19/Vite, Node campus API, Python academic service, existing Mongo-compatible persistence and Android TWA packaging.

**Spec:** docs/superpowers/specs/2026-10-29-student-identity-sync-design.md

## Global constraints
- Use only genuinely sourced college identity, published or explicitly scoped academic rules, and owner-bound caches.
- No CAPTCHA solver, password replay or invented source-change detector.
- Version 2.3.4; Android 20306; retain package/signing identity and current logo geometry/colours.
- Download publishing only vtu26418-design/Clinical. Preserve main, old immutable releases and private files.

## Review focus
- Long official names, empty official names, social aliases and nested official profiles.
- Unknown/ambiguous regulation, source-published summaries and noncredit/failure/repeated-course records.
- Known returning wrong password, upstream outage, first login, source expiry and owner switching.
- Old browser/PWA logo URLs, native icon preparation and reduced motion.
- Offline snapshots and delayed account responses must not cross account boundaries.

### Task 1: Home identity
**Files:** Home.jsx, StudentBand.jsx, new lib/student-identity.js and home CSS; tests/student-identity.test.js.
**Interface:** derive a bounded official identity from data.profile plus mode; preserve navigate callbacks and existing summary/reminders.
- [x] Reproduce first-word name/empty field rendering with real component/helper tests.
- [x] Implement full official name/ID fallback, visible compact college facts and readable mobile layout.
- [x] Verify long-name, social-alias, unknown identity and offline nested profile cases.

### Task 2: Regulation summaries
**Files:** academic-summary.js, useAcademicSummary.js, AcademicQuickAccess.jsx, ResultsDashboard.jsx and focused tests as necessary; avoid Home/identity/auth files.
**Interface:** preserve summary.overall/percentage/prepared API. Published values win; programme/regulation context stays official.
- [x] Reproduce any source/scale/label mismatch before changing code.
- [x] Correct identified calculation/provenance issues and share accurate summary labels between Home and Results.
- [x] Verify multiple official regulations, missing context, blocked policy and noncredit inputs.

### Task 3: App login and university verification
**Files:** portal-login.js, portal-password service, PortalLogin.jsx, PortalConnection and relevant source-status components/tests; coordinate root branding import edits.
**Interface:** returning valid account -> local durable session; first/reverification -> upstream challenge as required; source refresh remains owner-bound.
- [x] Trace and test first login, known returning login, incorrect local password, upstream expiry and refresh.
- [x] Fix unnecessary upstream calls or confusing source reconnect behavior without weakening verification.
- [x] Verify proper owner/account/CSRF protections and clear explicit sync/reverification actions.

### Task 4: Branding, release and integration
**Files:** central branding module, remaining app-brand JSX, index.html, vite.config.js, native icon/config files, version metadata and docs.
- [x] Audit current logo bytes, URLs, public cache policy and all app/PWA/native placements.
- [x] Reproduce old-path/stale-brand usage; adopt versioned current artwork paths, preserve full-logo motion/reduced-motion behavior.
- [x] Integrate agents and run frontend, campus, academic and Android suites plus production build.
- [x] Browser-test first/returning/reverification flows, Home/Results at 320/390/430/desktop, asset errors and offline restoration with fictional accounts.
- [x] Review security/calculation changes, build signed APK with retained private key, verify package/version/signature.
- [ ] Publish the verified package only to Clinical and verify hosted bytes; blocked by GitHub denying write access to mprem27. Clean archive and manifest verification are completed separately in the delivery receipt.
