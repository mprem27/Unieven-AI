# Native app and web update implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: use superpowers:subagent-driven-development or superpowers:executing-plans for the assigned task; use the current isolated non-Git combined project.

**Goal:** Ship2.3.5 with a standalone Android shell, shared current web UI/logo, correct install/update actions and repeatable fresh-opening animation.

**Architecture:** Native first-party asset hosting preserves existing HTTPS API/auth contracts. A restricted main-frame message bridge provides only named device actions; the React build remains shared by website and APK.

**Tech Stack:** Existing React/Vite/Node/FastAPI application; Java Android Activity/WebView/AndroidX WebKit; pinned Gradle/JDK/SDK.

**Spec:** docs/superpowers/specs/2026-10-29-native-app-update-design.md

## Global constraints
- Version2.3.5, Android20307, package in.velstudents.veltechams, original signing identity.
- Preserve approved logo design, all account/source fences, backend cookie/CORS rules, private configuration and original checkouts.
- No SSL bypass, addJavascriptInterface, arbitrary-origin bridge, silent installation or forced app-data reset.
- Publish project links only in vtu26418-design/Clinical when write access is actually available.

## Review focus
- Native static asset traversal, API paths, origin/redirect checks and main-frame bridge enforcement.
- Large or interrupted file transfers, cancellation and APK signer/package/version mismatch.
- Existing session storage across APK updates and first TWA-to-WebView migration.
- Normal web/PWA clients cannot be misclassified as native by query parameters alone.
- Opening animation replays only for actual openings, never ordinary navigation or permission/file picker completion.

### Task1 — Native Android container
Own android/native-template/**, scripts/android-native*.mjs, scripts/android-prepare.mjs, scripts/android-build.mjs, Android helper tests/dependencies. Preserve pure config validation; coordinate shared config changes with root.
- [ ] Reproduce TWA/custom-tab dependency and remote preparation gate.
- [ ] Add policy/bridge/file-transfer Java helpers and meaningful unit tests; build the origin-restricted Activity, native back/permissions/share/download/installer paths.
- [ ] Package validated local `frontend/dist` with matching app-build.json; preserve Gradle/wrapper checksum and signing checks.
- [ ] Verify Node helper suites, JVM policy tests and genuine native release compilation. Root handles private signing/release packaging.

### Task2 — Logo opening and restrained motion
Own AppLaunch.jsx, HybridLogo.jsx if needed, new native-motion-v235.css and focused launch/motion tests. Root imports CSS and updates branding constants.
- [ ] RED tests for repeated fresh document opens, no route replay, native long-return versus picker return, reduced/disabled animation.
- [ ] Remove session-wide suppression, preserve whole readable emblem and add restrained phased progress/press transitions without resetting forms/providers.
- [ ] Run focused rendered tests and one browser check with screenshots outside source.

### Task3 — GitHub source/build workflows
Own .github/workflows/**, scripts/ci-project-root.mjs, related tests and docs/GITHUB.md.
- [ ] Add failing tests for root/nested source layouts and ZIP-only/malformed layout errors.
- [ ] Make workflows resolve the supported source directory before caches/commands, build frontend locally and use Task1 native prepare interface.
- [ ] Validate signing-secret presence and optional association gate with clear messages; preserve actual nonzero check/build outcomes.
- [ ] Test resolver/workflow commands; coordinate native CLI with Task1. No remote publishing or owner-secret inspection.

### Task4 — Shared web/native platform integration and delivery
Root owns shared branding/version metadata, Vite app-build.json, frontend/lib/native-app.js, download/update/install components and notification integration.
- [ ] RED→GREEN transport and native/PWA distinction; integrate strict bounded chunked file transfer, native sharing/update actions and normal browser fallback.
- [ ] Disable service-worker registration in the native shell; preserve web/PWA opt-in updates and account persistence.
- [ ] Integrate independent tasks, full checks/build, browser/mobile/offline/action tests and independent review; fix material findings with regression.
- [ ] Compile/sign with retained key, independently inspect binary/bundled web version and public APK transport.
- [ ] Export complete source/web/native ZIP, guide and verified manifests. Publish only after Clinical write capability and verify the actual hosted bytes.
