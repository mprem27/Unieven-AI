# Install and share the Android APK

Share **https://app.veltech-mini-ams.me/#/install** with students. It shows current APK details and instructions before sign-in. The stable direct link is:

`https://app.veltech-mini-ams.me/api/campus/app-release/latest.apk`

Both links use the app's own domain. **Share download page** opens the available device share sheet or copies the guide link; **Copy APK link** copies the direct attachment. Share these links after publishing the verified release, not an authenticated settings page or GitHub Actions artifact.

## Install on Android

1. Open the public install page and choose **Download Android APK**.
2. Open the downloaded APK. If Android asks, review the source and approve that browser's permission to install this file.
3. Review Android's **Install** or **Update** prompt, then open **Veltech mini** from the app drawer.

The 2.3.5 APK is package `in.velstudents.veltechams`, Android versionCode 20307. It opens bundled React screens in a native Android Activity using Android System WebView; Chrome does not host its main screen. The website and optional browser-installed PWA remain separate clients.

The browser page reports **Download requested** after opening the attachment; it cannot confirm that the file was saved or installed. If the release changed, refresh its details and retry. Inside the native app, Settings → Android app & updates downloads the checked APK and opens Android's installer. Opening that installer does not confirm installation.

Updates require the same package/signing certificate and a higher versionCode. A first update from the old TWA may ask you to sign in once because Chrome and WebView use separate storage. Later same-key native updates preserve cookies and saved app data. Do not clear storage or uninstall for a routine update; expired sessions still require a normal login.

Android and Play Protect control source approval and reputation warnings. A valid signature or domain association cannot suppress them. Review the source/package and stop if they differ from the expected release; keep device protections enabled.

## Files and device permissions

The APK saves exported files through Android's save picker and uses its share sheet. Choose a destination or cancel. Camera, microphone and location use explicit Android permissions when requested; declining leaves other features available. Optional native alerts respect notification permission/preferences. Background delivery while the APK is closed is not promised.

The whole-logo opening animation runs on fresh opening and may replay after a longer background return. Ordinary navigation and short permission/file-picker returns do not restart it. Reduced-motion and disabled-animation preferences remain respected.

## APK updates and website updates

The APK's screens are packaged with that version. Accepting a signed APK update changes those screens; **Later · 24 hours** defers its reminder for the current account. A website deployment cannot replace the APK on your phone.

Website/PWA clients retain their opt-in service-worker updates, sessions, saved records and downloads. In a browser, **Install app** / **Add to Home screen** installs the separate web app. This PWA action is not offered inside the native APK. Browser standalone mode and query parameters never prove that the signed Android package is installed.

## Delivery checks for operators

`/api/campus/app-release` is public and contains no account information. The UI validates package, version, size, SHA-256 and the exact pinned URL `/api/campus/app-release/apk?sha=<sha256>`. The server serves only its locally published verified APK, checks its hash and returns 409 if the pinned checksum is stale. `latest.apk` selects the verified release current when opened; neither route redirects to another host.

Browser downloads use the direct same-origin attachment and rely on HTTPS, server publication/hash checks and Android's signature check; the browser does not hash the full APK in JavaScript before saving. The native updater additionally checks SHA-256, package, version and installed signing identity before invoking the installer, and rejects redirects. Operators should compare actual downloaded bytes with the published hash.

Use [the AWS/Cloudflare guide](ANDROID-UPDATE-DEPLOYMENT.md) to publish the frontend/API and release directory. Keep public release routes accessible without sign-in, edge caching or challenge/HTML substitution while retaining private API authentication. Digital Asset Links remain a separate optional association check. Verify the downloaded APK and test a real installation/same-key update before distribution. See [the 2.3.5 checklist](RELEASE-v2.3.5.md).
