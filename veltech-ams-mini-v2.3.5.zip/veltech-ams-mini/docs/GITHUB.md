# GitHub source, checks and Android builds

The selected project repository is [mprem27/Unieven-AI](https://github.com/mprem27/Unieven-AI). Use an account with write access to that repository. A GitHub `403`, `Resource not accessible by integration`, or a denied push needs the repository owner's access or policy change; editing a build workflow cannot grant account permissions. Keep project downloads and publishing in this repository.

Extract the **complete source ZIP** before committing. A branch that contains only source/web/APK ZIP downloads is a delivery branch, not a buildable source checkout. GitHub Actions does not extract release assets automatically. Your Windows computer uses Docker Desktop; GitHub's hosted Linux CI runner is independent and does not require an Ubuntu installation on your computer.

Both workflows accept one complete source tree in either of these layouts:

| Repository path | Required content |
| --- | --- |
| `.github/workflows/` | Workflow YAML files, always at the repository root so GitHub discovers them |
| `./` **or** `veltech-ams-mini/` | Project `package.json`, `frontend/`, `shared/`, `services/`, `scripts/`, `android/` and remaining source files |

Do not commit two complete source copies. The resolver checks the project manifests, npm lockfiles and academic requirements before cache setup or installation. Missing files, malformed manifests, escaping symlinks and ambiguous layouts stop with useful errors. No custom source-directory input is evaluated as a shell command.

For an initial source import, open PowerShell in the extracted project folder containing `package.json` and `compose.yaml`:

```powershell
git init
git add .
git status --short
git diff --cached --stat
git commit -m "Publish veltech-ams-mini"
git branch -M main
git remote add origin https://github.com/mprem27/Unieven-AI.git
git push -u origin main
```

For an existing repository, use its current checkout and branch instead of reinitializing it. If you keep the source inside `veltech-ams-mini/`, also place the supplied `.github/workflows/` files at the repository root.

Push `frontend`, `shared`, `services`, `docker`, `scripts`, `android` source/config example and lockfile, `docs`, `.github`, package/lock files, non-secret environment examples, PowerShell launchers and Compose files. Use the supplied `.gitignore`. Check the staged file list before committing.

Keep `.private`, real `.env` files, Atlas URIs/passwords, SMTP/VAPID/payment keys, student source captures, uploaded media/proofs, logs, `node_modules`, build outputs, APK/AAB files and Android signing keys outside Git. Preserve server/private-key backups separately. Signing certificates and `assetlinks.json` fingerprints are public; signing private keys are not. If a credential was committed, revoke/rotate it and clean repository history; deleting it in a later commit does not remove it from history.

The **Application checks** workflow runs on pushes and pull requests. It uses Node24, Python3.12, JDK21 and a temporary isolated Mongo8.2.3 service, installs frozen dependencies, runs the existing frontend/campus/academic/Android helper tests and builds the frontend. CI tests use fictional records and do not log into AMS. A failing test or build remains a failed job. It does not deploy or create production credentials.

The **Build signed Android release** workflow is started manually from Actions on a trusted source branch. Add the following repository Actions secrets, or environment secrets in the `android-release` environment used by the job:

- `ANDROID_KEYSTORE_BASE64`: base64 encoding of the **existing** release keystore.
- `ANDROID_STORE_PASSWORD`: that keystore's password.
- `ANDROID_KEY_PASSWORD`: the password for the existing `velstudents` signing alias.

The workflow checks that all three are present before installing SDK/build dependencies. Missing secrets produce named errors without printing values. Fork pull requests and environment protection rules can withhold secrets; use the intended repository and approve its configured environment rules. Keep the retained signing key and its backup: generating another key prevents an in-place update of existing installs.

The job pins Android platform36/build-tools36.1.0 and JDK21, builds `frontend/dist` locally with `npm ci`, installs/tests the Android helpers, then runs:

```text
node scripts/android-prepare.mjs --config android/config.release.json --local-web frontend/dist
node scripts/android-build.mjs --config android/config.release.json
```

The native APK packages this local production frontend. It does not need an already deployed copy of the new frontend to compile or open its own screen. The `require_domain_association` dispatch option defaults to **false**; enable it when you deliberately want the extra live `/.well-known/assetlinks.json` association check. A requested strict check still fails if the deployed statement does not match. This check is separate from native screen hosting and from APK signature/package/version verification.

Signing material is decoded only into a temporary directory with private permissions and removed on success or failure. A malformed/empty keystore secret fails; no replacement key is generated. The signed APK must pass signature, package/version and alignment checks. The public-release preparation step independently verifies the actual APK against its receipt before artifact upload.

Download the `veltech-ams-mini-android-release` Actions artifact after a successful job. It contains the signed APK, SHA-256 checksum, signing receipt, public `assetlinks.json`, and `public-release/` with a checksum-named APK plus `release.json`. Uploading an Actions artifact does not deploy the website, publish a GitHub Release or update the server's public APK endpoint. Follow the deployment guide for those steps and test the signed APK on a real Android device.

If a job fails, open its first failed step and retain the exact error. `Resolve and validate the source checkout` points to missing/extracted source; `Validate required signing secrets` names missing configuration; build/signature failures must be fixed at their reported cause. The workflows preserve nonzero results and never convert a failed build into a successful release.

Deploy using [deployment.md](deployment.md), then set the public HTTPS address for Android using [ANDROID.md](ANDROID.md). Do not deploy only `frontend/dist` and expect private AMS, events or community APIs to work: keep the campus API on the same public origin and the academic worker private.
