# Android release: Windows and CI

Release **2.3.5 / 20307**, package **in.velstudents.veltechams**, uses `android/config.release.json` and **https://app.veltech-mini-ams.me**. Keep the existing package and signing identity for every update.

The APK opens a native Android Activity with the production React UI bundled inside Android System WebView. Chrome, a Trusted Web Activity and a browser-installed PWA no longer host its primary screen. These are shared React screens, not a rewrite into native Android widgets. Bundled static resources belong to that APK release; `/api/*` requests still use the existing same-origin HTTPS backend and its cookie/authorization rules. External HTTPS links open externally. Network access remains necessary for login, live sync and server actions; existing owner-bound saved records retain their offline behavior.

Preparation uses local frontend files and does not require a deployed frontend, live DNS or Digital Asset Links. Signing, package/version and alignment checks remain mandatory. A successful build does not establish physical-phone acceptance, live AMS access or production deployment.

## Windows prerequisites and preparation

Running the application uses [Docker Desktop and PowerShell](V2-UPGRADE.md); no Ubuntu installation or terminal is required. Building an APK locally additionally needs Node >=22.12 (Node 24 recommended), JDK 21, Android SDK platform 36, Build-Tools 36.1.0 and platform-tools. Install these through Android Studio's SDK Manager or the official command-line tools and accept the SDK licenses. Set `JAVA_HOME` to the actual JDK installation and `ANDROID_HOME` to the SDK. The project pins Gradle 8.11.1 and AGP 8.9.1; wrapper and Gradle distribution checksums are pinned. Minimum Android is 7.0/API 24 with a compatible, current Android System WebView.

In PowerShell at the project root:

```powershell
$env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk"
npm --prefix frontend ci
npm --prefix frontend run build
npm --prefix android ci
npm --prefix android test
node .\scripts\android-prepare.mjs --config .\android\config.release.json --local-web frontend/dist
node .\scripts\android-build.mjs --config .\android\config.release.json --dry-run
```

Preparation validates `frontend/dist/app-build.json`, the release version and current artwork before copying the frontend into `android/generated`. It rejects mismatched or missing assets. `--local-icon` is no longer used: the launcher icon comes from the validated frontend build. Generated files are replaced during preparation; change source/configuration instead. `--dry-run` validates configuration/build planning without creating an APK. `android/config.example.json` contains an invalid placeholder; use the explicit release configuration above for this app.

## Retain the signing key

**Never generate a replacement key for an update.** Restore the existing `velstudents-release.keystore`, alias `velstudents`, to `android/private/`, or set `CAMPUS_ANDROID_KEY_DIRECTORY` to its protected external directory. Keep the key and password in separate private backups, verify a restored key with `keytool -list`, and preserve the original distributed certificate. A public APK or certificate fingerprint cannot recover a lost private key.

Private keystores/passwords never belong in source, delivery ZIPs, screenshots, logs, CI artifacts, Docker images or public media. The release config contains only the keystore filename and alias. Existing deployment cookie/encryption/VAPID/academic-link keys and database/media volumes must also survive upgrades.

Earlier domain evidence listed a different certificate, and the older inaccessible Actions APK could not be inspected. Compare the certificate of the APK actually distributed to users with the new release before rollout. If they differ, rebuild with the original key; do not ask users to uninstall or clear data to hide a signing mismatch.

## Sign on Windows

After preparation and private-key restoration:

```powershell
node .\scripts\android-build.mjs --config .\android\config.release.json
```

The reviewed PowerShell helper prompts securely for the existing keystore/key passwords. For PKCS12, use the same password for both. If Windows blocks that helper, unblock only the reviewed file with `Unblock-File .\scripts\android-build.ps1`, subject to your organization's policy.

The build runs Gradle `assembleRelease`, 16 KiB alignment, APK signing/verification, release package/version/launchable-activity checks and final alignment verification. Public outputs are:

- `android/out/veltech-ams-mini-release.apk`
- `android/out/veltech-ams-mini-release.apk.sha256`
- `android/out/signing-receipt.json`

The receipt records `runtime: android-native`, bundled web version, asset digest, APK checksum, signing certificate and a separate `domainAssociation` result. Live association is best effort by default. Add `--require-domain-association` only when a matching deployed statement must gate delivery; a failed strict check leaves the signed local APK intact and exits nonzero. Native screen hosting needs no domain-association success. The scripts never bypass TLS errors.

## CI or other build hosts

The manual **Build signed Android release** workflow uses the same locally built frontend and retained key. Its hosted Linux runner does not require Ubuntu on your Windows computer. The optional `require_domain_association` input defaults to **false**. Complete source may be at repository root or `veltech-ams-mini/`; a branch containing only ZIP downloads cannot run the build. See [the GitHub guide](GITHUB.md) for existing-key secrets and source layout. CI uploads public artifacts; it does not deploy AWS, change Cloudflare or publish a GitHub Release.

Linux/macOS builds use the same prepare/build commands with `ANDROID_HOME`, `JAVA_HOME`, `CAMPUS_ANDROID_KEY_DIRECTORY` when needed, and private process variables `CAMPUS_ANDROID_STORE_PASSWORD` / `CAMPUS_ANDROID_KEY_PASSWORD`. Never store passwords in JSON or command arguments. Managed build hosts must retain configured proxy and CA trust for Node/Java/Gradle; do not disable TLS to resolve network failures.

## Publish public release files

With the Android SDK configured, independently verify the actual APK and prepare a local directory:

```powershell
node scripts/publish-android-release.mjs --apk=android/out/veltech-ams-mini-release.apk --receipt=android/out/signing-receipt.json --out=app-releases --notes="Native Android 2.3.5"
```

This rechecks signature, identity and alignment, copies `<sha256>.apk`, and atomically replaces `release.json`. Copy those public files to the existing persistent media release directory, APK first and manifest last. All campus replicas must read the same directory. Keep old APKs until rollout is checked. For the existing Docker media mount, retain these server settings:

```dotenv
CAMPUS_APK_DIRECTORY=/app/media/app-releases
CAMPUS_ANDROID_PACKAGE_ID=in.velstudents.veltechams
```

The public `/api/campus/app-release`, `/api/campus/app-release/apk?sha=...` and `/api/campus/app-release/latest.apk` routes serve only verified public metadata/APKs before sign-in. Keep same-origin HTTPS, no-store, nosniff and attachment headers; exclude these routes from edge caching/challenge substitution. Protected account/academic APIs retain existing authentication. See [AWS/Cloudflare rollout](ANDROID-UPDATE-DEPLOYMENT.md).

Students use **https://app.veltech-mini-ams.me/#/install**. Browsers download the own-domain attachment. The native app accepts only the own-origin pinned APK endpoint, rejects redirects, checks checksum/package/version/signing identity, then opens Android's installer. Android controls unknown-source approval, Install/Update and Play Protect warnings. The app cannot install silently or suppress OS warnings.

## Optional Digital Asset Links

Generate the public statement from the actual verified certificate:

```powershell
node scripts/android-assetlinks.mjs --config android/config.release.json --fingerprint "FULL_COLON_SEPARATED_SHA256_CERTIFICATE_FINGERPRINT"
```

Publish `android/out/assetlinks.json` at **https://app.veltech-mini-ams.me/.well-known/assetlinks.json** with HTTP 200/application/json, no redirect, login or challenge. Copy it into `frontend/public/.well-known/assetlinks.json` before rebuilding the website, or use the existing exact-route proxy overlay. It is public metadata. Association supports existing link/browser behavior and the optional build gate; it does not supply the native APK's screens.

## Installation, permissions and updates

The first TWA-to-native update may require one login: Chrome/TWA storage and WebView storage are separate. Later native updates with the same package/certificate retain WebView cookies, IndexedDB and app-private data. Expired/revoked sessions still require normal authentication. Never automatically clear app data, uninstall, reset databases or regenerate signing keys as an update step.

File exports use Android's save picker; sharing uses the system share sheet. Camera, microphone and location access require first-party requests and explicit Android permission approval. Denial/cancellation must leave the rest usable. Optional native alerts respect OS permission and app preferences; background push when the APK is closed is not promised. The browser/PWA keeps its separate notification behavior.

Website/PWA updates use their service-worker lifecycle and **Later** preference without deleting sessions/downloads. The native APK does not register that website service worker or offer PWA installation; changing its bundled UI requires a signed APK update. Reloading the native screen reopens its bundled version.

Before distribution, test an actual phone's launcher, login/logout, navigation/back/keyboard, AMS sync, two-account isolation, saved records, file save/cancel, sharing, denied/granted permissions, notifications and same-key update persistence. With an authorized USB device, `adb install -r android/out/veltech-ams-mini-release.apk` updates without requesting a data reset. Keep device, live AMS and production checks separate from build evidence. See [the release checklist](RELEASE-v2.3.5.md).
