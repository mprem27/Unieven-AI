> Administration and university publishing: [University publishing, bulk seating, Windows upgrade and configuration guide](docs/UNIVERSITY-PUBLISHING.md).

# veltech-ams-mini

Combined student, faculty and administrator workspace · **2.3.5**.

Start with [the 2.3.5 release and rollout checklist](docs/RELEASE-v2.3.5.md). The Android APK now opens its bundled React screens inside a native Android Activity using Android System WebView. Its API still uses **https://app.veltech-mini-ams.me**. Website/PWA updates and signed APK updates are separate.

The [student identity and university sync guide](docs/V2.3.4-STUDENT-SYNC.md) still covers account login, source verification and calculation rules.

Start with [the Windows Docker setup and upgrade guide](docs/V2-UPGRADE.md). New installations use PostgreSQL through FerretDB. Existing configuration is preserved until you complete a verified migration.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup.ps1
```

Open **http://localhost:4100** after setup. The same login identifies the account role. No Ubuntu terminal is required.

- [Upgrade, migration, roles, events, placements and app updates](docs/V2-UPGRADE.md)
- [SMTP configuration](docs/EMAIL-SMTP.md)
- [Android signing and packaging](docs/ANDROID.md)
- [Android installation and sharing](docs/ANDROID-INSTALL-SHARE.md)
- [Verification and limitations](docs/VERIFICATION.md)

The source package excludes secrets, student data, database files and signing keys. Building a signed APK requires the retained release key and configured deployment URL; local frontend packaging does not require the domain to be available. PostgreSQL software is free; hosted disk and service limits still apply.

For the original Atlas setup only, choose `Setup.ps1 -Database Atlas`. Existing Atlas installations can continue using their original configuration.

Developed by VEL STUDENTS.
