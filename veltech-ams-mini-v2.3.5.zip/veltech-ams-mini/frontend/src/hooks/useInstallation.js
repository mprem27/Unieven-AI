import {useEffect,useState} from 'react';
import {androidLaunch} from '../lib/update-policy.js';
import {androidInstallation} from '../lib/app-release.js';
import {getNativeRuntime,isNativeShell} from '../lib/native-app.js';
export default function useInstallation(legacy=androidLaunch){
 const native=isNativeShell();
 const [state,setState]=useState(()=>({...legacy,native,pending:native,error:''}));
 useEffect(()=>{
  if(!native)return;
  let active=true;
  getNativeRuntime().then(info=>{if(active)setState({...androidInstallation({nativeRuntime:info}),native:true,pending:false,error:'',runtime:info});}).catch(error=>{if(active)setState({installed:true,versionCode:null,native:true,pending:false,error:error.message});});
  return()=>{active=false;};
 },[native]);
 return state;
}
