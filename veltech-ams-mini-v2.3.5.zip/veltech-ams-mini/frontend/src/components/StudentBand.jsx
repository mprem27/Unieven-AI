import {Avatar} from './UI';
import {homeStudentIdentity} from '../lib/student-identity';
import {ChevronRight} from 'lucide-react';

// `profile` is an already selected official profile for existing callers.
// Home passes its derived identity so its heading and facts share one source.
export default function StudentBand({profile={},identity:providedIdentity,onProfile,compact=false}){
 const identity=providedIdentity || homeStudentIdentity({officialProfile:profile});
 return <section className={`student-band-v234 ${compact?'is-compact':'panel'}`} aria-label="College details">
  {!compact?<button type="button" className="student-band-profile" onClick={onProfile} aria-label="Open student details"><Avatar name={identity.name || identity.universityId} src={identity.photo} size="large"/><span><strong>{identity.title}</strong>{identity.universityId&&identity.universityId!==identity.title?<small>{identity.universityId}</small>:null}</span><ChevronRight size={18}/></button>:null}
  {identity.facts.length?<dl className="student-band-facts">{identity.facts.map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>:<p className="student-band-unavailable">Official student details are not available yet.</p>}
 </section>;
}
