import {APP_LOGO} from '../lib/branding.js';
export default function HybridLogo(){
 return <img className="hybrid-logo-mark" src={APP_LOGO} alt="" decoding="sync"/>;
}
