import {useEffect} from 'react';
import {useCampus} from '../context/CampusContext';
export default function DownloadFeedbackBridge(){
 const {notify}=useCampus();
 useEffect(()=>{
  const failure=event=>{if(typeof event.detail==='string' && event.detail)notify(event.detail.slice(0,1000),'error');};
  window.addEventListener('campus-download-error',failure);
  return()=>window.removeEventListener('campus-download-error',failure);
 },[notify]);
 return null;
}
