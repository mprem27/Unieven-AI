import {APP_LOGO} from '../lib/branding.js';
import {useEffect,useRef,useState} from 'react';
import {useAppPreferences} from '../context/AppPreferences';
import HybridLogo from './HybridLogo';
export default function AppLaunch({children}){
 const {preferences}=useAppPreferences();
 // The root stays mounted across routes. A new document gets its own opening,
 // including refreshes in a tab whose sessionStorage already contains data.
 const [pending,setPending]=useState(true),[phase,setPhase]=useState('arriving');
 const active=useRef(true),enabled=preferences.openingAnimation;
 const reduced=preferences.motion==='reduced' || globalThis.matchMedia?.('(prefers-reduced-motion:reduce)')?.matches===true;
 const visible=pending && enabled;
 useEffect(()=>{
  if(!pending)return;
  if(!enabled){active.current=false;setPending(false);return;}
  const timers=[];
  if(!reduced){
   timers.push(setTimeout(()=>setPhase('settled'),620));
   timers.push(setTimeout(()=>setPhase('leaving'),900));
  }
  timers.push(setTimeout(()=>{active.current=false;setPending(false);},reduced?180:1100));
  return()=>timers.forEach(clearTimeout);
 },[pending,enabled,reduced]);
 useEffect(()=>{
  const target=globalThis.window;
  if(!target?.addEventListener)return;
  const resume=event=>{
   const detail=event.detail;
   if(!enabled || active.current || !detail || detail.externalAction || typeof detail.backgroundMs!=='number' || !Number.isFinite(detail.backgroundMs) || detail.backgroundMs<30000)return;
   // Guard synchronously: duplicate native notifications in the same render
   // cannot queue multiple openings or restart an in-progress timer.
   active.current=true;setPhase('arriving');setPending(true);
  };
  target.addEventListener('veltech:native-resume',resume);
  return()=>target.removeEventListener('veltech:native-resume',resume);
 },[enabled]);
 return <><div className="app-launch-content" inert={visible} aria-hidden={visible || undefined}>{children}</div>{visible?<div className="app-launch" role="status" aria-label="Opening Veltech mini" data-motion={reduced?'reduced':'full'} data-phase={phase} data-transition={phase==='leaving'?'leaving':'arriving'}><div className="app-launch-mark" aria-hidden="true">{reduced?<img className="app-launch-static" src={APP_LOGO} alt=""/>:<HybridLogo/>}</div><strong>veltech mini</strong>{reduced?null:<div className="app-launch-progress" aria-hidden="true"><span/></div>}</div>:null}</>;
}
