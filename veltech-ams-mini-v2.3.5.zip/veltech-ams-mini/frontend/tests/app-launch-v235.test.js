import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import React,{act,useState} from 'react';
import {create} from 'react-test-renderer';
import {transformWithOxc} from 'vite';
import {loadJsx,moduleUrl} from './helpers/jsx.js';
import {APP_LOGO} from '../src/lib/branding.js';

globalThis.IS_REACT_ACT_ENVIRONMENT=true;
// Render the real logo as well as the real launch component. Only preference
// inputs and browser APIs are supplied by the fixture.
const logoFile=new URL('../src/components/HybridLogo.jsx',import.meta.url);
const logoSource=(await fs.readFile(logoFile,'utf8')).replace("'../lib/branding.js'",JSON.stringify(new URL('../lib/branding.js',logoFile).href));
const {code}=await transformWithOxc(logoSource,logoFile.pathname,{jsx:{runtime:'automatic'}});
const logoModule=moduleUrl(code.replace(/from "react\/jsx-runtime"/g,`from ${JSON.stringify(import.meta.resolve('react/jsx-runtime'))}`));
const preferences=moduleUrl('export const useAppPreferences=()=>({preferences:globalThis.__launchPreferences});');
const {default:AppLaunch}=await loadJsx(new URL('../src/components/AppLaunch.jsx',import.meta.url),{'../context/AppPreferences':preferences,'./HybridLogo':logoModule});
const overlay=view=>view.root.findAllByProps({'aria-label':'Opening Veltech mini'});
const content=view=>view.root.findByProps({className:'app-launch-content'});

function environment({reduced=false,seen=false,...preferences}={}){
 const saved={window:globalThis.window,sessionStorage:globalThis.sessionStorage,matchMedia:globalThis.matchMedia};
 const window=new EventTarget(),storage=new Map(seen?[['veltech:launch:v234','seen'],['veltech:launch:v235','seen']]:[]);
 Object.assign(globalThis,{window,sessionStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)},matchMedia:()=>({matches:reduced})});
 globalThis.__launchPreferences={openingAnimation:true,motion:'system',...preferences};
 return {resume(detail){window.dispatchEvent(new CustomEvent('veltech:native-resume',{detail}));},restore(){Object.assign(globalThis,saved);delete globalThis.__launchPreferences;}};
}

test('every fresh mount shows the whole logo despite a seen flag in the same tab storage',async t=>{
 const env=environment({seen:true});t.mock.timers.enable({apis:['setTimeout']});let view;
 try{
  for(let opening=0;opening<3;opening++){
   await act(async()=>{view=create(React.createElement(AppLaunch,null,'Campus'));});
   assert.equal(overlay(view).length,1,'a fresh opening must replay');
   assert.equal(content(view).props.inert,true);
   const images=view.root.findAllByType('img');
   assert.equal(images.length,1);assert.equal(images[0].props.src,APP_LOGO);
   await act(async()=>t.mock.timers.tick(1101));
   assert.equal(overlay(view).length,0);assert.equal(content(view).props.inert,false);
   await act(async()=>view.unmount());view=null;
  }
 }finally{await act(async()=>view?.unmount());env.restore();}
});

test('ordinary route rerenders do not replay or remount a drafted form',async t=>{
 const env=environment();t.mock.timers.enable({apis:['setTimeout']});let view,mounts=0;
 function Draft({route}){const [value,setValue]=useState(()=>{mounts++;return '';});return React.createElement('input',{'aria-label':route,value,onChange:event=>setValue(event.target.value)});}
 try{
  await act(async()=>{view=create(React.createElement(AppLaunch,null,React.createElement(Draft,{route:'Home'})));});
  await act(async()=>t.mock.timers.tick(1101));
  await act(async()=>view.root.findByType('input').props.onChange({target:{value:'Keep this draft'}}));
  await act(async()=>view.update(React.createElement(AppLaunch,null,React.createElement(Draft,{route:'Settings'}))));
  assert.equal(overlay(view).length,0);assert.equal(view.root.findByType('input').props.value,'Keep this draft');assert.equal(mounts,1);
 }finally{await act(async()=>view?.unmount());env.restore();}
});

test('a native return after 30 seconds replays without remounting children',async t=>{
 const env=environment();t.mock.timers.enable({apis:['setTimeout']});let view,mounts=0;
 function Draft(){const [value,setValue]=useState(()=>{mounts++;return 'Saved draft';});return React.createElement('input',{value,onChange:event=>setValue(event.target.value)});}
 try{
  await act(async()=>{view=create(React.createElement(AppLaunch,null,React.createElement(Draft)));});
  await act(async()=>t.mock.timers.tick(1101));
  await act(async()=>env.resume({backgroundMs:30000,externalAction:false}));
  assert.equal(overlay(view).length,1);assert.equal(content(view).props.inert,true);
  await act(async()=>t.mock.timers.tick(1101));
  assert.equal(overlay(view).length,0);assert.equal(mounts,1);assert.equal(view.root.findByType('input').props.value,'Saved draft');
 }finally{await act(async()=>view?.unmount());env.restore();}
});

test('short native returns, permission pickers and malformed resumes leave the form available',async t=>{
 const env=environment();t.mock.timers.enable({apis:['setTimeout']});let view;
 try{
  await act(async()=>{view=create(React.createElement(AppLaunch,null,React.createElement('input',{defaultValue:'Draft'})));});
  await act(async()=>t.mock.timers.tick(1101));
  for(const detail of [{backgroundMs:29999,externalAction:false},{backgroundMs:60000,externalAction:true},{backgroundMs:0,externalAction:false},{backgroundMs:'30000',externalAction:false},{backgroundMs:Infinity,externalAction:false},null]){
   await act(async()=>env.resume(detail));
   assert.equal(overlay(view).length,0,JSON.stringify(detail));assert.equal(content(view).props.inert,false);
  }
 }finally{await act(async()=>view?.unmount());env.restore();}
});

test('duplicate native resume notifications do not extend an active opening',async t=>{
 const env=environment();t.mock.timers.enable({apis:['setTimeout']});let view;
 try{
  await act(async()=>{view=create(React.createElement(AppLaunch,null,'Campus'));});
  await act(async()=>t.mock.timers.tick(1101));
  await act(async()=>{env.resume({backgroundMs:45000,externalAction:false});env.resume({backgroundMs:45000,externalAction:false});});
  assert.equal(overlay(view).length,1);
  await act(async()=>t.mock.timers.tick(700));
  await act(async()=>env.resume({backgroundMs:45000,externalAction:false}));
  await act(async()=>t.mock.timers.tick(401));
  assert.equal(overlay(view).length,0);assert.equal(content(view).props.inert,false);
 }finally{await act(async()=>view?.unmount());env.restore();}
});

for(const preference of [{motion:'reduced'},{reduced:true}])test(`reduced motion uses a brief static logo for fresh and native openings (${JSON.stringify(preference)})`,async t=>{
 const env=environment(preference);t.mock.timers.enable({apis:['setTimeout']});let view;
 try{
  await act(async()=>{view=create(React.createElement(AppLaunch,null,'Campus'));});
  assert.equal(overlay(view)[0].props['data-motion'],'reduced');assert.equal(view.root.findAllByType('img').length,1);
  assert.equal(view.root.findAllByProps({className:'app-launch-progress'}).length,0);
  await act(async()=>t.mock.timers.tick(181));assert.equal(overlay(view).length,0);
  await act(async()=>env.resume({backgroundMs:30000,externalAction:false}));
  assert.equal(overlay(view).length,1);
  assert.equal(overlay(view)[0].props['data-motion'],'reduced');
  await act(async()=>t.mock.timers.tick(181));assert.equal(overlay(view).length,0);
 }finally{await act(async()=>view?.unmount());env.restore();}
});

test('disabled openings never block fresh or native use and toggling the preference releases an active launch',async t=>{
 const env=environment({openingAnimation:false});t.mock.timers.enable({apis:['setTimeout']});let view;
 try{
  await act(async()=>{view=create(React.createElement(AppLaunch,null,'Campus'));});
  assert.equal(overlay(view).length,0);assert.equal(content(view).props.inert,false);
  await act(async()=>env.resume({backgroundMs:60000,externalAction:false}));assert.equal(overlay(view).length,0);
  globalThis.__launchPreferences.openingAnimation=true;
  await act(async()=>view.update(React.createElement(AppLaunch,null,'Settings')));assert.equal(overlay(view).length,0);
  await act(async()=>env.resume({backgroundMs:60000,externalAction:false}));assert.equal(overlay(view).length,1);
  globalThis.__launchPreferences.openingAnimation=false;
  await act(async()=>view.update(React.createElement(AppLaunch,null,'Settings')));assert.equal(overlay(view).length,0);assert.equal(content(view).props.inert,false);
  await act(async()=>t.mock.timers.tick(2000));assert.equal(overlay(view).length,0);
 }finally{await act(async()=>view?.unmount());env.restore();}
});

test('normal motion reaches a settled phase before fading and releases interaction after the fade',async t=>{
 const env=environment();t.mock.timers.enable({apis:['setTimeout']});let view;
 try{
  await act(async()=>{view=create(React.createElement(AppLaunch,null,'Campus'));});
  assert.equal(overlay(view)[0].props['data-phase'],'arriving');
  assert.equal(view.root.findAllByProps({className:'app-launch-progress'}).length,1);
  await act(async()=>t.mock.timers.tick(650));assert.equal(overlay(view)[0].props['data-phase'],'settled');
  await act(async()=>t.mock.timers.tick(270));assert.equal(overlay(view)[0].props['data-transition'],'leaving');assert.equal(content(view).props.inert,true);
  await act(async()=>t.mock.timers.tick(181));assert.equal(overlay(view).length,0);assert.equal(content(view).props.inert,false);
 }finally{await act(async()=>view?.unmount());env.restore();}
});
