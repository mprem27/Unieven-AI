import test from 'node:test';
import assert from 'node:assert/strict';
import axios from 'axios';
import {request,setApiOwner} from '../src/lib/api.js';
import {indexedDB} from 'fake-indexeddb';
import {clearWorkspaceCache,rememberVerifiedWorkspace,readRememberedWorkspace} from '../src/lib/workspace-cache.js';
import {browserFixture} from './helpers/jsx.js';

test('a response started for a previous account cannot return its private records',async()=>{
 const old=axios.defaults.adapter;let release;
 axios.defaults.adapter=config=>new Promise(resolve=>{release=()=>resolve({data:{studentId:'private-old-record'},status:200,headers:{},config});});
 try{
  setApiOwner('previous-owner');
  const pending=request('/academics/overview');
  setApiOwner('current-owner');release();
  await assert.rejects(pending,error=>axios.isCancel(error));
 }finally{axios.defaults.adapter=old;setApiOwner('');}
});

test('rejected university verification retains saved records; revoked app authentication clears them',async()=>{
 const browser=browserFixture(),adapter=axios.defaults.adapter,savedEvent=globalThis.CustomEvent;globalThis.indexedDB=indexedDB;
 globalThis.CustomEvent=class extends Event{constructor(type,options){super(type);this.detail=options.detail;}};
 let revoked=0;browser.window.addEventListener('campus:session-revoked',()=>revoked++);
 axios.defaults.adapter=async()=>{throw {response:{status:401,data:{message:'Credentials rejected'}}};};
 try{
  await clearWorkspaceCache();await rememberVerifiedWorkspace('owner',{profile:{id:'owner'},subjects:[{name:'Saved Algorithms'}]});setApiOwner('owner');
  await assert.rejects(request('/portal/login',{method:'POST',body:{username:'vtu00000',password:'incorrect-university-password'}}));
  assert.equal(revoked,0);assert.equal((await readRememberedWorkspace()).owner,'owner');
  await assert.rejects(request('/academics/ams/refresh',{method:'POST',body:{}}));
  assert.equal(revoked,1,'A revoked app session must still be cleared');assert.equal(await readRememberedWorkspace(),null);
 }finally{axios.defaults.adapter=adapter;setApiOwner('');await clearWorkspaceCache();delete globalThis.indexedDB;globalThis.CustomEvent=savedEvent;browser.restore();}
});

test('an old-account conflict cannot trigger restoration after another account was adopted',async()=>{
 const old=axios.defaults.adapter;let release;let events=0;
 const originalWindow=globalThis.window,originalEvent=globalThis.CustomEvent;
 globalThis.window={dispatchEvent(){events++;}};globalThis.CustomEvent=class{constructor(type,options){this.type=type;this.detail=options.detail;}};
 axios.defaults.adapter=config=>new Promise((_resolve,reject)=>{release=()=>reject({response:{status:409,data:{code:'ACCOUNT_CHANGED',message:'Account changed'}},config});});
 try{
  setApiOwner('previous-owner');const pending=request('/events');
  setApiOwner('current-owner');release();
  await assert.rejects(pending,error=>axios.isCancel(error));
  assert.equal(events,0);
 }finally{axios.defaults.adapter=old;setApiOwner('');globalThis.window=originalWindow;globalThis.CustomEvent=originalEvent;}
});
