import test from 'node:test';
import assert from 'node:assert/strict';
import axios from 'axios';
import React,{act} from 'react';
import {create} from 'react-test-renderer';
import {MemoryRouter} from 'react-router-dom';
import {loadJsx,moduleUrl,browserFixture,settle} from './helpers/jsx.js';
import {setApiOwner,setApiReadOnly} from '../src/lib/api.js';
globalThis.IS_REACT_ACT_ENVIRONMENT=true;
const context=await loadJsx(new URL('../src/context/CampusContext.jsx',import.meta.url),{'./AppPreferences':moduleUrl('export const useAppPreferences=()=>({preferences:{refreshSeconds:0}})')});
const ui=await loadJsx(new URL('../src/components/UI.jsx',import.meta.url));
globalThis.__sourceReviewUi=ui;
const Connection=(await loadJsx(new URL('../src/components/AmsConnection.jsx',import.meta.url),{
 '../context/CampusContext':moduleUrl('export const useCampus=()=>globalThis.__sourceReviewCampus;'),
 './UI':moduleUrl('export const {Button,Field,Feedback,SectionTitle}=globalThis.__sourceReviewUi;'),
 './SourceSyncStatus':moduleUrl('export default function Status(){return null;}'),
})).default;
const active=()=>({state:'partial',sourceSession:{state:'active',refreshAvailable:true,expiresInSeconds:1800}});

test('verified same-owner source reconnection enables manual sync with automatic refresh off; ordinary app login does not renew it',async()=>{
 const browser=browserFixture(),adapter=axios.defaults.adapter;
 const user={id:'source-review-owner',name:'Official student',accountRole:'student'};
 let campus,view,refreshes=0;
 axios.defaults.adapter=async config=>{
  let data=[];
  if(config.url==='/session')data={user,csrfToken:'fixture'};
  else if(config.url==='/academics/overview')data={profile:{name:'Official student'},academic:{},syncStatus:active()};
  else if(config.url==='/academics/sync-status')data=active();
  else if(config.url==='/academics/ams/refresh'){
   refreshes++;
   if(refreshes===1)throw {response:{status:409,data:{message:'Verify university access again.'}}};
   data={queued:true,syncStatus:{...active(),state:'syncing'}};
  }else if(config.url.startsWith('/academic-calendar') || config.url==='/timetable-rooms')data={entries:[]};
  return {data,status:200,headers:{},config};
 };
 function Probe(){campus=context.useCampus();globalThis.__sourceReviewCampus=campus;return React.createElement(Connection);}
 const syncButton=()=>view.root.findAllByType('button').find(node=>node.children.some(child=>child==='Sync university records'));
 try{
  await act(async()=>{view=create(React.createElement(MemoryRouter,null,React.createElement(context.CampusProvider,null,React.createElement(Probe))));await settle();});
  const deadline=Date.now()+2000;
  while(!campus.data.workspaceReady && Date.now()<deadline)await act(async()=>{await settle();});
  assert.equal(campus.data.workspaceReady,true);
  await act(async()=>{await assert.rejects(campus.refreshUniversity(),error=>error.status===409);});
  assert.equal(campus.data.sourceRefresh.state,'reconnect_required');
  assert.equal(syncButton().props.disabled,true);
  await act(async()=>{await campus.resume({user,csrfToken:'returning',source:'workspace-password'});await settle();});
  assert.equal(campus.data.sourceRefresh.state,'reconnect_required','An app password cannot renew university access');
  await act(async()=>{await campus.resume({user,csrfToken:'reverified',source:'ams-manual-login',refreshAvailable:true,syncStatus:active()});await settle();});
  assert.notEqual(campus.data.sourceRefresh?.state,'reconnect_required');
  assert.equal(syncButton().props.disabled,false,'Fresh verification must unlock manual sync without a page reload');
  await act(async()=>{await campus.refreshUniversity();await settle();});
  assert.equal(refreshes,2,'Manual source refresh must dispatch even when automatic refresh is disabled');
 }finally{
  if(view)await act(async()=>view.unmount());
  axios.defaults.adapter=adapter;setApiOwner('');setApiReadOnly(false);browser.restore();
  delete globalThis.__sourceReviewCampus;
 }
});
