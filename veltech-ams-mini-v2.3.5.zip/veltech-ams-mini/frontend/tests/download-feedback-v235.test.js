import test from 'node:test';
import assert from 'node:assert/strict';
import React,{act} from 'react';
import {create} from 'react-test-renderer';
import {loadJsx,moduleUrl,browserFixture} from './helpers/jsx.js';
globalThis.IS_REACT_ACT_ENVIRONMENT=true;
test('download failures reach the current page and its listener is removed on unmount',async()=>{
 const env=browserFixture(),messages=[];globalThis.__downloadNotice=(...args)=>messages.push(args);let view;
 try{
  const {default:Bridge}=await loadJsx(new URL('../src/components/DownloadFeedbackBridge.jsx',import.meta.url),{'../context/CampusContext':moduleUrl('export const useCampus=()=>({notify:globalThis.__downloadNotice});')});
  await act(async()=>{view=create(React.createElement(Bridge));});
  const failure=new Event('campus-download-error');failure.detail='Android could not save the file.';
  await act(async()=>window.dispatchEvent(failure));assert.deepEqual(messages,[['Android could not save the file.','error']]);
  await act(async()=>view.unmount());view=null;window.dispatchEvent(failure);assert.equal(messages.length,1);
 }finally{if(view)await act(async()=>view.unmount());delete globalThis.__downloadNotice;env.restore();}
});
