import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import React,{act} from 'react';
import {create} from 'react-test-renderer';
import {transformWithOxc} from 'vite';
import {loadJsx,moduleUrl,browserFixture,settle} from './helpers/jsx.js';
import {saveAlertPreferences} from '../src/lib/notifications.js';

globalThis.IS_REACT_ACT_ENVIRONMENT=true;
globalThis.__nativeNotificationUi=await loadJsx(new URL('../src/components/UI.jsx',import.meta.url));
const file=new URL('../src/components/NotificationPreferences.jsx',import.meta.url);
const replacements={
 '../context/CampusContext':moduleUrl('export const useCampus=()=>globalThis.__nativeNotificationState.campus;'),
 '../context/AppPreferences':moduleUrl('export const useAppPreferences=()=>({preferences:globalThis.__nativeNotificationState.preferences,update:patch=>{const state=globalThis.__nativeNotificationState;state.preferences={...state.preferences,...patch};}});'),
 '../lib/api':moduleUrl('export const request=(...args)=>{globalThis.__nativeNotificationState.requests.push(args);return Promise.resolve({});};'),
 './UI':moduleUrl('export const {Button,Field,Feedback,SectionTitle,Badge}=globalThis.__nativeNotificationUi;')
};
// The normal JSX loader does not load stylesheet side effects in Node. Keep
// the real component and its helpers, omitting only that browser-only import.
let source=(await fs.readFile(file,'utf8')).replace(/^import ['"].*\.css['"];?$/gm,'');
source=source.replace(/from\s+(['"])([^'"]+)\1/g,(_match,_quote,path)=>`from ${JSON.stringify(replacements[path] || (path.startsWith('.')?new URL(path+(/\.(?:m?js|jsx)$/.test(path)?'':'.js'),file).href:import.meta.resolve(path)))}`);
const {code}=await transformWithOxc(source,file.pathname,{jsx:{runtime:'automatic'}});
const {default:NotificationPreferences,NotificationAlertBridge}=await import(moduleUrl(code.replace(/from "react\/jsx-runtime"/g,`from ${JSON.stringify(import.meta.resolve('react/jsx-runtime'))}`)));
const {default:AcademicSettings}=await loadJsx(new URL('../src/components/AcademicSettings.jsx',import.meta.url),replacements);
const {default:PermissionSettings}=await loadJsx(new URL('../src/components/PermissionSettings.jsx',import.meta.url),replacements);

function fixture({native=true,optedIn=true,alerts={}}={}){
 const browser=browserFixture(),previous={Notification:globalThis.Notification,AudioContext:globalThis.AudioContext};
 const state={campus:{mode:'connected',data:{profile:{id:'alpha',absentAlertsEnabled:false},notifications:[],notificationReady:{academic:true,social:true}},refresh:async()=>{}},preferences:{browserAlerts:optedIn},requests:[],native:[],web:[],permission:false,notificationPermission:'denied',webPermissions:0,registrations:0,audio:0};
 globalThis.__nativeNotificationState=state;
 const registration={showNotification:async(title,options)=>state.web.push({title,options}),pushManager:{getSubscription:async()=>({endpoint:'https://push.example.test/device'})}};
 navigator.serviceWorker={getRegistration:async()=>{state.registrations++;return registration;}};
 class WebNotification{static permission='granted';static requestPermission=async()=>{state.webPermissions++;return 'granted';};constructor(title,options){state.web.push({title,options});}}
 globalThis.Notification=window.Notification=WebNotification;
 window.isSecureContext=true;
 globalThis.AudioContext=class{state='running';currentTime=0;destination={};createOscillator(){globalThis.__nativeNotificationState.audio++;return {frequency:{},connect(){},start(){},stop(){}};}createGain(){return {gain:{setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){}};}};
 if(native){window.VeltechNativeBridge={postMessage(value){const message=JSON.parse(value);state.native.push(message);if(message.type==='notificationPermission')state.notificationPermission=state.permission?'granted':'denied';const result=message.type==='hello'?{runtime:'android-native',packageId:'in.velstudents.veltechams',versionCode:20307,versionName:'2.3.5',capabilities:{notifications:true},notificationPermission:state.notificationPermission}:message.type==='notificationPermission'?{granted:state.permission}:{shown:true};queueMicrotask(()=>this.onmessage({data:JSON.stringify({id:message.id,ok:true,result})}));}};}
 saveAlertPreferences('connected:alpha',alerts);
 return {state,restore(){Object.assign(globalThis,previous);delete globalThis.__nativeNotificationState;browser.restore();}};
}
async function mount(Component){let view;await act(async()=>{view=create(React.createElement(Component));await settle();});return view;}
async function rerender(view,Component=NotificationAlertBridge){await act(async()=>{view.update(React.createElement(Component));await settle();});}
async function click(view,label){const button=view.root.findAllByType('button').find(node=>node.children.includes(label));assert.ok(button,`Missing ${label} action`);await act(async()=>{await button.props.onClick();await settle();});}
const text=view=>JSON.stringify(view.toJSON());
const notices=state=>state.native.filter(message=>message.type==='notify');

test('Android permission is requested only by the explicit system-alert action and denial explains Android settings',async()=>{
 const env=fixture({optedIn:false});let view;
 try{
  view=await mount(NotificationPreferences);assert.equal(env.state.native.length,0);assert.match(text(view),/System alerts/);
  await click(view,'Enable system alerts');assert.deepEqual(env.state.native.map(message=>message.type),['notificationPermission']);assert.equal(env.state.preferences.browserAlerts,false);assert.match(text(view),/Android settings/);
  env.state.permission=true;await click(view,'Enable system alerts');assert.equal(env.state.preferences.browserAlerts,true);assert.match(text(view),/while the app is open/);
  await click(view,'Turn off system alerts');assert.equal(env.state.preferences.browserAlerts,false);assert.equal(env.state.native.length,2);
  await click(view,'Save alert preferences');assert.equal(env.state.registrations,0);assert.equal(env.state.webPermissions,0);assert.deepEqual(env.state.requests,[]);
 }finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('fresh native notices use generic content and the internal destination without browser APIs or duplicate audio',async()=>{
 const env=fixture({alerts:{soundEnabled:true}});let view;
 try{
  env.state.campus.data.notifications=[{id:'old',source:'academic',read:false}];view=await mount(NotificationAlertBridge);assert.equal(env.state.native.length,0);
  env.state.campus.data.notifications=[...env.state.campus.data.notifications,{id:'new',source:'academic',type:'ATTENDANCE_ABSENT',title:'Student name was absent',body:'Private attendance details',read:false},{id:'already-read',source:'social',read:true}];await rerender(view);
  assert.equal(notices(env.state).length,1);assert.deepEqual(notices(env.state)[0].payload,{title:'New campus notification',body:'Open your campus inbox to read the update.',tag:'campus:academic:new',url:'/#/attendance',silent:false});
  assert.equal(env.state.audio,0);assert.equal(env.state.registrations,0);assert.equal(env.state.web.length,0);assert.equal(env.state.webPermissions,0);
  env.state.campus.data.notifications=[...env.state.campus.data.notifications];await rerender(view);assert.equal(notices(env.state).length,1);
 }finally{if(view)await act(async()=>view.unmount());env.restore();}
});

for(const [label,alerts,visibility]of [['sound disabled',{},'visible'],['silent mode',{soundEnabled:true,silent:true},'visible'],['quiet hours',{soundEnabled:true,quietHoursEnabled:true,quietHoursStart:'00:00',quietHoursEnd:'00:00'},'visible'],['hidden app',{soundEnabled:true},'hidden']])test(`native notices honor ${label}`,async()=>{
 const env=fixture({alerts});let view;
 try{document.visibilityState=visibility;view=await mount(NotificationAlertBridge);env.state.campus.data.notifications=[{id:'fresh',source:'social',postId:'post',read:false}];await rerender(view);assert.equal(notices(env.state).length,1);assert.equal(notices(env.state)[0].payload.silent,true);assert.equal(notices(env.state)[0].payload.url,'/#/community/posts/post');assert.equal(env.state.audio,0);}
 finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('native opt-out preserves foreground sound without posting system notices',async()=>{
 const env=fixture({optedIn:false,alerts:{soundEnabled:true}});let view;
 try{view=await mount(NotificationAlertBridge);env.state.campus.data.notifications=[{id:'fresh',source:'social',read:false}];await rerender(view);assert.equal(env.state.audio,2);assert.equal(env.state.native.length,0);assert.equal(env.state.registrations,0);assert.equal(env.state.web.length,0);}
 finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('native alerts retain source readiness, source identities and account baselines',async()=>{
 const env=fixture();let view;
 try{
  env.state.campus.data.notificationReady.social=false;view=await mount(NotificationAlertBridge);
  env.state.campus.data.notifications=[{id:'shared',source:'academic',read:false}];env.state.campus.data.notificationReady={academic:true,social:true};await rerender(view);assert.equal(notices(env.state).length,0);
  env.state.campus.data.notifications=[...env.state.campus.data.notifications,{id:'shared',source:'social',read:false}];await rerender(view);assert.equal(notices(env.state).length,1);assert.equal(notices(env.state)[0].payload.tag,'campus:social:shared');
  env.state.campus.data.profile={id:'beta'};env.state.campus.data.notifications=[{id:'beta-existing',source:'social',read:false}];await rerender(view);assert.equal(notices(env.state).length,1);
  env.state.campus.data.notifications=[...env.state.campus.data.notifications,{id:'beta-fresh',source:'social',read:false}];await rerender(view);assert.equal(notices(env.state).length,2);
  env.state.campus.mode='demo';env.state.campus.data.notifications=[{id:'preview',source:'social',read:false}];await rerender(view);assert.equal(notices(env.state).length,2);
  env.state.campus.mode='connected';await rerender(view);assert.equal(notices(env.state).length,2);
 }finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('browser settings retain explicit Web Notification permission and existing push preference updates',async()=>{
 const env=fixture({native:false,optedIn:false});let view;
 try{
  view=await mount(NotificationPreferences);assert.equal(env.state.webPermissions,0);await click(view,'Enable browser alerts');assert.equal(env.state.webPermissions,1);assert.equal(env.state.preferences.browserAlerts,true);
  await click(view,'Save alert preferences');assert.equal(env.state.registrations,1);assert.equal(env.state.requests[0][0],'/academics/push/preferences');assert.equal(env.state.requests[0][1].body.endpoint,'https://push.example.test/device');assert.equal(env.state.native.length,0);
 }finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('browser alerts retain service-worker delivery with one foreground sound',async()=>{
 const env=fixture({native:false,alerts:{soundEnabled:true}});let view;
 try{view=await mount(NotificationAlertBridge);env.state.campus.data.notifications=[{id:'new',source:'academic',read:false}];await rerender(view);assert.equal(env.state.web.length,1);assert.equal(env.state.web[0].options.silent,true);assert.equal(env.state.audio,2);assert.equal(env.state.registrations,1);assert.equal(env.state.native.length,0);}
 finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('native academic settings save account choices and lead to foreground system alerts without Web Push',async()=>{
 const env=fixture();let view,refreshes=0;env.state.campus.refresh=async()=>{refreshes++;};
 try{
  view=await mount(AcademicSettings);assert.deepEqual(env.state.requests,[],'The APK must not inspect browser push status');assert.equal(view.root.findAllByType('button').length,1);assert.equal(view.root.findByType('a').props.href,'#/settings/notifications');assert.match(text(view),/while the app is open/);
  await act(async()=>view.root.findAllByType('select')[0].props.onChange({target:{value:'no'}}));await click(view,'Save preferences');assert.deepEqual(env.state.requests, [['/academics/preferences',{method:'PATCH',body:{smsEnabled:true,notificationsEnabled:false}}]]);assert.equal(refreshes,1);assert.equal(env.state.webPermissions,0);assert.equal(env.state.registrations,0);
 }finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('browser academic settings keep browser push status and subscription controls',async()=>{
 const env=fixture({native:false});let view;
 try{view=await mount(AcademicSettings);assert.equal(env.state.requests[0][0],'/academics/push/status');assert.ok(view.root.findAllByType('button').some(button=>button.children.includes('Enable push')));assert.equal(view.root.findAllByType('a').length,0);}
 finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('native device permissions show current Android notification state and refresh it after explicit permission requests',async()=>{
 const env=fixture();let view;
 try{
  delete window.Notification;delete globalThis.Notification;view=await mount(PermissionSettings);assert.deepEqual(env.state.native.map(message=>message.type),['hello']);const row=()=>view.root.findAllByProps({className:'device-setting-row'})[0];assert.equal(row().findByType('span').children.join(''),'denied');assert.match(text(view),/Android settings/);
  env.state.permission=true;await act(async()=>{await row().findByType('button').props.onClick();await settle();});assert.deepEqual(env.state.native.map(message=>message.type),['hello','notificationPermission','hello']);assert.equal(row().findByType('span').children.join(''),'granted');assert.match(text(view),/while the app is open/);
  env.state.notificationPermission='denied';await click(view,'Refresh permission status');assert.equal(row().findByType('span').children.join(''),'denied');assert.equal(env.state.native.filter(message=>message.type==='notificationPermission').length,1);assert.equal(env.state.webPermissions,0);
 }finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('native camera and location permission checks retain user-triggered Web APIs and release the camera',async()=>{
 const env=fixture();let view,stops=0;const captures=[],positions=[];navigator.mediaDevices={getUserMedia:async options=>{captures.push(options);return {getTracks:()=>[{stop(){stops++;}}]};}};navigator.geolocation={getCurrentPosition(success,_failure,options){positions.push(options);success({coords:{latitude:13,longitude:80,accuracy:10},timestamp:Date.now()});}};
 try{
  view=await mount(PermissionSettings);assert.deepEqual(captures,[]);assert.deepEqual(positions,[]);await act(async()=>{await view.root.findAllByProps({className:'device-setting-row'})[1].findByType('button').props.onClick();await settle();});assert.deepEqual(captures,[{video:{facingMode:{ideal:'environment'}},audio:false}]);assert.equal(stops,1);
  await act(async()=>{await view.root.findAllByProps({className:'device-setting-row'})[2].findByType('button').props.onClick();await settle();});assert.deepEqual(positions,[{enableHighAccuracy:true,timeout:15000,maximumAge:0}]);assert.match(text(view),/does not save your location/);assert.ok(env.state.native.every(message=>message.type==='hello'));
 }finally{if(view)await act(async()=>view.unmount());env.restore();}
});

test('browser device permission checks retain Web Notification permission requests',async()=>{
 const env=fixture({native:false});let view;
 try{view=await mount(PermissionSettings);assert.equal(env.state.webPermissions,0);await act(async()=>{await view.root.findAllByProps({className:'device-setting-row'})[0].findByType('button').props.onClick();await settle();});assert.equal(env.state.webPermissions,1);assert.equal(env.state.native.length,0);}
 finally{if(view)await act(async()=>view.unmount());env.restore();}
});
