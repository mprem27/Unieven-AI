import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {transformWithOxc} from 'vite';
import React,{act} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {create} from 'react-test-renderer';
import {moduleUrl} from './helpers/jsx.js';
import {workspaceSnapshot} from '../src/lib/workspace-cache.js';

globalThis.IS_REACT_ACT_ENVIRONMENT=true;
const identity=await import('../src/lib/student-identity.js').catch(()=>({}));
async function jsxModule(relative,replacements={}){
 const file=new URL(relative,import.meta.url),source=await fs.readFile(file,'utf8');
 const rewritten=source.replace(/from\s+(['"])([^'"]+)\1/g,(_match,_quote,path)=>`from ${JSON.stringify(replacements[path] || (path.startsWith('.')?new URL(path+(/\.(?:m?js|jsx)$/.test(path)?'':'.js'),file).href:import.meta.resolve(path)))}`);
 const {code}=await transformWithOxc(rewritten,file.pathname,{jsx:{runtime:'automatic'}});
 return moduleUrl(code.replace(/from "react\/jsx-runtime"/g,`from ${JSON.stringify(import.meta.resolve('react/jsx-runtime'))}`));
}
const ui=await jsxModule('../src/components/UI.jsx');
const bandUrl=await jsxModule('../src/components/StudentBand.jsx',{'./UI':ui});
const {default:StudentBand}=await import(bandUrl);
const passive=moduleUrl('export default function Fixture(){return null;}');
const summary=moduleUrl('export default function Fixture(){return null;} export function useStudentSummary(){return {};}');
const {default:Home}=await import(await jsxModule('../src/pages/Home.jsx',{
 '../context/CampusContext':moduleUrl('export function useCampus(){return globalThis.__identityCampus;}'),
 '../components/UI':ui,'../components/StudentBand':bandUrl,
 '../components/AcademicQuickAccess':summary,
 ...Object.fromEntries(['LiveReminderHub','AttendanceOverview','ClassTimeline','SourceSyncStatus','HomeReels'].map(name=>[`../components/${name}`,passive])),
}));
const fullName='Ananya Lakshmi Narayanan Subramanian';
const official={name:fullName,vtuNumber:'VTU00042',department:'Computer Science and Engineering',degree:'B.Tech',semester:'5',section:'C',batch:'2023–2027',mentor:'Dr. Test Mentor',photo:'/fixtures/student-portrait.svg'};
function campus(profile,mode='connected'){
 return {mode,loading:false,notify(){},today:'2026-10-29',data:{profile,subjects:[],classes:[],notices:[],events:[]}};
}
function homeMarkup(profile,mode='connected'){
 globalThis.__identityCampus=campus(profile,mode);
 try{return renderToStaticMarkup(React.createElement(Home,{navigate(){},openNotice(){},openEvent(){}}));}
 finally{delete globalThis.__identityCampus;}
}
function officialIdentity(profile,mode='connected'){
 assert.equal(typeof identity.homeStudentIdentity,'function','Home needs a shared official identity view-model');
 return identity.homeStudentIdentity(profile,mode);
}

test('Home heading retains the complete official name instead of a social alias or first word',()=>{
 const html=homeMarkup({name:'CampusAlias',image:'/social-photo.png',officialProfile:official});
 assert.ok(html.includes(`<h1>${fullName}</h1>`),'the entire official name must be the page heading');
 assert.doesNotMatch(html,/CampusAlias|social-photo/);
});

test('Home uses the official university number when the official name is missing',()=>{
 const html=homeMarkup({name:'CampusAlias',studentId:'UNVERIFIED',officialProfile:{vtuNumber:'VTU00042'}});
 assert.match(html,/<h1>VTU00042<\/h1>/);assert.doesNotMatch(html,/CampusAlias|UNVERIFIED/);
});

test('Home with an unknown official identity keeps social identity out of the student header',()=>{
 const html=homeMarkup({name:'CampusAlias',department:'Social department',image:'/social-photo.png'});
 assert.match(html,/<h1>Student overview<\/h1>/);assert.match(html,/Official student details are not available yet/);
 assert.doesNotMatch(html,/CampusAlias|Social department|social-photo|Not provided/);
});

test('StudentBand exposes up to six available college facts without a disclosure or empty rows',()=>{
 const html=renderToStaticMarkup(React.createElement(StudentBand,{profile:official,onProfile(){}}));
 assert.doesNotMatch(html,/<details|Not provided/);
 assert.equal((html.match(/<dt>/g)||[]).length,6);
 for(const value of ['Computer Science and Engineering','B.Tech','5','C','2023–2027','Dr. Test Mentor'])assert.ok(html.includes(value),value);
 const sparse=renderToStaticMarkup(React.createElement(StudentBand,{profile:{name:fullName,branch:'Computer Science',semester:'5'},onProfile(){}}));
 assert.match(sparse,/Computer Science/);assert.equal((sparse.match(/<dt>/g)||[]).length,2);
 assert.doesNotMatch(sparse,/Not provided/);
});

test('official identity never borrows social fields and accepts a fictional demo identity',()=>{
 const account={name:'CampusAlias',department:'Social department',image:'/social-photo.png',officialProfile:official};
 const value=officialIdentity(account);
 assert.equal(value.name,fullName);assert.equal(value.title,fullName);assert.equal(value.universityId,'VTU00042');assert.equal(value.photo,'/fixtures/student-portrait.svg');
 const unknown=officialIdentity({name:'CampusAlias',studentId:'UNVERIFIED',image:'/social-photo.png'});
 assert.equal(unknown.title,'Student overview');assert.equal(unknown.photo,'');assert.equal(unknown.universityId,'');assert.deepEqual(unknown.facts,[]);
 assert.equal(officialIdentity({name:fullName,photo:'/demo.png'},'demo').title,fullName);
});

test('official identity preserves offline nested degree and branch without mutating cached records',()=>{
 const account={id:'fictional-owner',name:'CampusAlias',officialProfile:{name:fullName,vtuNumber:'VTU00042',degree:'B.Tech',branch:'Computer Science',semester:5,section:'C',batch:'2023–2027'}};
 const cached=workspaceSnapshot({profile:account,academic:{}},'fictional-owner');
 const before=structuredClone(cached),value=officialIdentity(cached.profile);
 assert.equal(value.title,fullName);assert.deepEqual(value.facts.slice(0,2),[['Department','Computer Science'],['Degree','B.Tech']]);assert.deepEqual(cached,before);
});

test('identity omits unavailable and malformed facts and stays bounded when every official field exists',()=>{
 const value=officialIdentity({officialProfile:{...official,year:'3',rollNumber:'ROLL42',academicYear:'2026–2027'}});
 assert.equal(value.facts.length,6);
 const sparse=officialIdentity({officialProfile:{name:' ',vtuNumber:'VTU00042',department:'Not provided',degree:'N/A',semester:null,section:'—',batch:'',mentor:{name:'Object'},year:false}});
 assert.equal(sparse.title,'VTU00042');assert.deepEqual(sparse.facts,[]);
});

test('Home retains sync, academic navigation and student details actions',async()=>{
 const routes=[],notifications=[];let view;
 globalThis.__identityCampus={...campus({name:'CampusAlias',officialProfile:official}),notify:value=>notifications.push(value)};
 const originalError=console.error;console.error=(message,...args)=>{if(!String(message).includes('react-test-renderer is deprecated'))originalError(message,...args);};
 try{
  await act(async()=>{view=create(React.createElement(Home,{navigate:(...args)=>routes.push(args),openNotice(){},openEvent(){}}));});
  const buttons=view.root.findAllByType('button');
  await act(async()=>buttons.find(node=>node.props['aria-label']==='View university sync').props.onClick());
  await act(async()=>buttons.find(node=>node.children.some(value=>value==='Academics')).props.onClick());
  await act(async()=>buttons.find(node=>node.props['aria-label']==='Open student details').props.onClick());
  assert.deepEqual(routes,[['settings','connections'],['academics'],['profile']]);
  globalThis.__identityCampus={...globalThis.__identityCampus,mode:'demo'};
  await act(async()=>view.update(React.createElement(Home,{navigate:(...args)=>routes.push(args),openNotice(){},openEvent(){}})));
  await act(async()=>view.root.findAllByType('button').find(node=>node.props['aria-label']==='View university sync').props.onClick());
  assert.deepEqual(notifications,['Preview records are fictional.']);assert.equal(routes.length,3);
 }finally{await act(async()=>view?.unmount());delete globalThis.__identityCampus;console.error=originalError;}
});
