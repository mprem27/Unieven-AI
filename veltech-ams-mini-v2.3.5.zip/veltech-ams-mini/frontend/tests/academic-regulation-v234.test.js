import test from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {MemoryRouter} from 'react-router-dom';
import {createServer} from 'vite';
import {academicSummary} from '../src/lib/academic-summary.js';
import {resultMetrics,resultTrend,publishedResultSummary,filterResults} from '../src/lib/academic-results.js';
import {weightedGpa} from '../src/lib/gpa.js';
import {loadJsx,moduleUrl} from './helpers/jsx.js';

const record={source:'ams',courseCode:'C101',semester:'I',grade:'A',credits:4};
const profile=(regulation,degree='B.Tech')=>({id:'fictional',officialProfile:{degree,regulation}});
const summarize=(regulation,extra={})=>academicSummary({results:[record],studentProfile:profile(regulation),...extra});

test('an explicit regulation never borrows unsupported letters from a selected generic scale',()=>{
 for(const [regulation,grade,scheme] of [['UGE2025','S','sab'],['UGE2025','AB','plus'],['UGE2021','E','sab'],['UGE2021','O','ugc'],['Regulations 2013','AB','sab']]){
  const summary=summarize(regulation,{results:[{...record,grade}],calculation:{scheme}});
  assert.equal(summary.prepared.grades[0].gradePoints,undefined,`${regulation} does not document ${grade}`);
  assert.equal(summary.overall.cgpa,null);assert.equal(summary.estimatedPoints,false);
 }
});

test('an unknown programme or explicit unknown regulation cannot select generic course points',()=>{
 for(const studentProfile of [profile('UGE2025','M.Tech'),profile('Unverified regulation'),profile('UGE2025','')]){
  const summary=summarize('UGE2025',{studentProfile});
  assert.equal(summary.overall.cgpa,null);assert.equal(summary.prepared.grades[0].gradePoints,undefined);
 }
});

test('source numeric course points and source scales retain precedence for an otherwise unsupported letter',()=>{
 const numeric=summarize('UGE2025',{results:[{...record,grade:'S',gradePoints:7.5}]});
 const scale=summarize('UGE2025',{results:[{...record,grade:'S'}],gradeScale:[{grade:'S',points:7.5}]});
 for(const summary of [numeric,scale]){assert.equal(summary.overall.cgpa,7.5);assert.equal(summary.estimatedPoints,false);}
});

test('documented grade scales and percentage conversions stay specific to the explicit programme and regulation',()=>{
 const modern=summarize('UGE2025'),revised=summarize('UGE2021'),historical=summarize('Regulations 2013');
 assert.equal(modern.overall.cgpa,8);assert.equal(modern.percentage.value,80);assert.equal(modern.percentage.source,'official-rule');
 assert.equal(revised.overall.cgpa,9);assert.equal(revised.percentage.value,85);assert.equal(revised.percentage.source,'project-rule');
 assert.equal(historical.overall.cgpa,9);assert.equal(historical.percentage.value,81);assert.equal(historical.percentage.source,'official-rule');
});

test('explicit zero-credit noncredit rows do not suppress selected or semester averages',()=>{
 const summary=summarize('UGE2025',{results:[record,{...record,courseCode:'NC',grade:'P',credits:0}]});
 assert.equal(summary.overall.cgpa,8);assert.equal(summary.overall.points[0].value,8);
 assert.equal(resultMetrics(summary.prepared.grades).complete,true);
 assert.equal(resultTrend(summary.prepared.grades)[0].value,8);
});

test('one semester average includes equivalent Roman and numeric source semester labels',()=>{
 const summary=summarize('UGE2025',{results:[{...record,semester:'II'},{...record,courseCode:'C102',semester:'2',grade:'B',credits:2}]});
 assert.equal(summary.overall.cgpa,44/6);assert.equal(summary.overall.points.length,1);
 assert.equal(summary.overall.points[0].value,44/6,'4 credits at 8 and 2 credits at 6 belong to the same semester');
});

test('selecting a source semester keeps equivalent numeric and Roman records visible',()=>{
 const rows=[{...record,semester:'II'},{...record,courseCode:'C102',semester:'2'},{...record,courseCode:'C103',semester:'III'}];
 const selected=filterResults(rows,{semester:'II'});
 assert.equal(selected.length,2);assert.deepEqual(selected.map(row=>row.semester),['II','2'],'source labels remain intact');
});

test('GPA calculations and published summaries reject values above the ten-point range without losing raw records',()=>{
 const summary=summarize('UGE2025',{results:[{...record,gradePoints:11}],creditSummary:[{label:'CGPA',value:11},{label:'SGPA',semester:'I',value:12}]});
 assert.equal(summary.prepared.grades[0].gradePoints,11,'the source record remains visible');
 assert.equal(summary.overall.cgpa,null);assert.equal(summary.overall.points[0].value,null);
 assert.equal(weightedGpa([{credits:4,gradePoints:11}]).complete,false);
 assert.equal(publishedResultSummary([{label:'CGPA',value:11}]).cgpa,null);
});

const {default:AcademicQuickAccess}=await loadJsx(new URL('../src/components/AcademicQuickAccess.jsx',import.meta.url),{
 '../context/CampusContext':moduleUrl('export const useCampus=()=>({mode:"connected",data:{subjects:[],classes:[]}});'),
 '../hooks/useAcademicSummary':moduleUrl('export default function useAcademicSummary(){throw new Error("Quick access receives its summary from Home");}'),
});
const quick=summary=>renderToStaticMarkup(React.createElement(AcademicQuickAccess,{summary,navigate(){},expanded:true}));

test('Home explicitly names a generic CGPA estimate and avoids claiming a complete semester history',()=>{
 const summary=summarize('',{results:[record]});
 const html=quick(summary);
 assert.match(html,/9\.00 CGPA estimate/);assert.match(html,/85\.00%.*project estimate/i);
 const numeric=quick(summarize('UGE2025'));
 assert.match(numeric,/8\.00 CGPA/);assert.match(numeric,/80\.00%.*official conversion/i);
 assert.doesNotMatch(numeric,/all semesters|all source semesters/i);
});

test('Home distinguishes published CGPA and unavailable percentage from calculated values',()=>{
 const summary=summarize('UGE2025',{creditSummary:[{label:'CGPA',value:8.25}],policyStatus:'unavailable'});
 const html=quick(summary);assert.match(html,/8\.25 CGPA/);assert.match(html,/published by AMS/i);assert.match(html,/percentage unavailable/i);
 const estimate=summarize('UGE2021');assert.match(quick(estimate),/85\.00%.*project estimate/i);
});

const vite=await createServer({root:new URL('..',import.meta.url).pathname,server:{middlewareMode:true,hmr:false},appType:'custom'});
try{
 const {default:ResultsDashboard}=await vite.ssrLoadModule('/src/components/ResultsDashboard.jsx');
 await test('Results gives its overall estimate the same explicit provenance as Home',()=>{
  const html=renderToStaticMarkup(React.createElement(MemoryRouter,null,React.createElement(ResultsDashboard,{mode:'demo',results:[record],studentProfile:{degree:'B.Tech'}})));
  assert.match(html,/Overall CGPA estimate/);assert.match(html,/Project estimate.*selected 10-point scale/);
 });
}finally{await vite.close();}
