import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {androidInstallation} from '../src/lib/app-release.js';
const modulePath=new URL('../src/lib/native-app.js',import.meta.url);
async function native(){assert.ok(existsSync(modulePath),'The native Android transport must be implemented');return import(modulePath);}
const info={runtime:'android-native',packageId:'in.velstudents.veltechams',versionCode:20307,versionName:'2.3.5',capabilities:{saveFile:true,download:true,share:true,notifications:true},notificationPermission:'default'};
function fixture(handler){
 const previous=globalThis.window,window=new EventTarget(),messages=[];
 window.location={origin:'https://app.veltech-mini-ams.me'};
 window.VeltechNativeBridge={postMessage(text){const message=JSON.parse(text);messages.push(message);queueMicrotask(async()=>{try{const result=await handler(message);window.VeltechNativeBridge.onmessage?.({data:JSON.stringify({id:message.id,ok:true,result})});}catch(error){window.VeltechNativeBridge.onmessage?.({data:JSON.stringify({id:message.id,ok:false,error:error.message})});}});}};
 globalThis.window=window;
 return {window,messages,restore(){window.dispatchEvent(new Event('pagehide'));globalThis.window=previous;}};
}
test('native runtime is recognized without a Chrome referrer and query-only launches cannot manufacture it',()=>{
 assert.equal(androidInstallation({nativeRuntime:info}).installed,true);
 assert.equal(androidInstallation({nativeRuntime:info}).versionCode,20307);
 assert.equal(androidInstallation({search:'?androidPackage=in.velstudents.veltechams&androidVersionCode=99999'}).installed,false);
 assert.equal(androidInstallation({nativeRuntime:{...info,packageId:'other.example.app'}}).installed,false);
});
test('normal browser has no native transport and cannot silently claim an Android install',async()=>{
 const api=await native(),previous=globalThis.window;globalThis.window=new EventTarget();
 try{assert.equal(api.isNativeShell(),false);assert.equal(await api.getNativeRuntime(),null);await assert.rejects(api.nativeRequest('hello'),/Android|native/i);}finally{globalThis.window=previous;}
});
test('native handshake validates package/runtime, coalesces requests and keeps no installation claim in storage',async()=>{
 const api=await native(),f=fixture(async()=>info);
 try{const [a,b]=await Promise.all([api.getNativeRuntime(),api.getNativeRuntime()]);assert.equal(a.versionCode,20307);assert.equal(b.runtime,'android-native');assert.equal(f.messages.length,1);}
 finally{f.restore();}
 const wrong=fixture(async()=>({...info,packageId:'other.example.app'}));try{await assert.rejects(api.getNativeRuntime(),/identity|runtime|package/i);}finally{wrong.restore();}
});
test('PDF export uses bounded ordered chunks, checksum and the Android save action',async()=>{
 const api=await native(),parts=[],body=new Uint8Array(150123).fill(65),sha=createHash('sha256').update(body).digest('hex');let expected=0;
 const f=fixture(async m=>{
  if(m.type==='beginFile'){assert.equal(m.payload.bytes,body.length);assert.equal(m.payload.sha256,sha);assert.equal(m.payload.mimeType,'application/pdf');return {transferId:'own-transfer'};}
  if(m.type==='appendFile'){assert.equal(m.payload.index,expected++);const bytes=Buffer.from(m.payload.base64,'base64');assert.ok(bytes.length<=65536);parts.push(bytes);return {received:bytes.length};}
  if(m.type==='finishFile'){assert.deepEqual(Buffer.concat(parts),Buffer.from(body));return {saved:true};}
  throw new Error('Unexpected action');
 });
 try{assert.equal(await api.saveNativeFile('semester.pdf',new Blob([body],{type:'application/pdf'})),true);assert.equal(expected,3);assert.ok(f.messages.every(m=>JSON.stringify(m).length<196608));}finally{f.restore();}
});
test('user cancellation rejects as AbortError and cleans an unfinished transfer',async()=>{
 const api=await native(),f=fixture(async m=>m.type==='beginFile'?{transferId:'cancel-me'}:m.type==='finishFile'?{saved:false,cancelled:true}:{received:3});
 try{await assert.rejects(api.saveNativeFile('notes.txt',new Blob(['abc'])),e=>e.name==='AbortError');assert.ok(f.messages.some(m=>m.type==='cancelFile'));}finally{f.restore();}
});
test('oversize files, stale owners and untrusted APK URLs never reach the native device bridge',async()=>{
 const api=await native(),f=fixture(async()=>({}));
 try{
  await assert.rejects(api.saveNativeFile('large.pdf',new Blob([new Uint8Array(15*1024*1024+1)])),/large|15/i);
  await assert.rejects(api.saveNativeFile('old.pdf',new Blob(['private']),{isCurrent:()=>false}),e=>e.name==='AbortError');
  await assert.rejects(api.downloadNativeApk({available:true,url:'https://other.example/app.apk'}),/release|verified|Android/i);
  assert.equal(f.messages.length,0);
 }finally{f.restore();}
});
test('verified native update resolves the pinned APK path to the configured first-party HTTPS origin',async()=>{
 const api=await native(),f=fixture(async()=>({installerOpened:true})),sha='ab'.repeat(32),path=`/api/campus/app-release/apk?sha=${sha}`;
 try{await api.downloadNativeApk({available:true,packageId:info.packageId,versionCode:20308,versionName:'2.3.6',bytes:12000,sha256:sha,url:path});assert.equal(f.messages[0].payload.url,'https://app.veltech-mini-ams.me'+path);}finally{f.restore();}
});
test('native errors are propagated and an unrelated reply cannot settle another request',async()=>{
 const api=await native();let ready;
 const f=fixture(async()=>new Promise(resolve=>{ready=resolve;}));
 try{const pending=api.nativeRequest('hello');f.window.VeltechNativeBridge.onmessage({data:JSON.stringify({id:'different-id',ok:true,result:info})});await Promise.resolve();ready(info);assert.equal((await pending).runtime,'android-native');}
 finally{f.restore();}
 const rejected=fixture(async()=>{throw new Error('Android permission was denied');});try{await assert.rejects(api.nativeRequest('notificationPermission'),/permission was denied/);}finally{rejected.restore();}
});
