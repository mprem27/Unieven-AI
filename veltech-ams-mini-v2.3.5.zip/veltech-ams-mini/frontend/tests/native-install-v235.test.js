import test from 'node:test';
import assert from 'node:assert/strict';
import React,{act} from 'react';
import {create} from 'react-test-renderer';
import {loadJsx,moduleUrl,browserFixture,settle} from './helpers/jsx.js';
import '../src/lib/update-policy.js';
globalThis.IS_REACT_ACT_ENVIRONMENT=true;
const sha='ad'.repeat(32),release={available:true,versionName:'2.3.6',versionCode:20308,bytes:12345,packageId:'in.velstudents.veltechams',sha256:sha,url:`/api/campus/app-release/apk?sha=${sha}`};
const info={runtime:'android-native',packageId:release.packageId,versionName:'2.3.5',versionCode:20307,capabilities:{download:true,share:true}};
const ui=moduleUrl(`import React from ${JSON.stringify(import.meta.resolve('react'))};export const Button=({children,busy,variant,...props})=>React.createElement('button',{...props,disabled:busy||props.disabled},children);export const Badge=({children})=>React.createElement('span',null,children);export const Feedback=({error,success})=>error||success?React.createElement('p',null,error||success):null;`);
const text=node=>node.children.map(child=>typeof child==='string'?child:text(child)).join('');
function installBridge(window,{runtime=info,onDownload=async()=>({installerOpened:true})}={}){
 window.location={origin:'https://app.veltech-mini-ams.me'};
 const messages=[];
 window.VeltechNativeBridge={postMessage(value){const message=JSON.parse(value);messages.push(message);queueMicrotask(async()=>{try{const result=message.type==='hello'?runtime:message.type==='downloadApk'?await onDownload(message.payload):{shared:true};window.VeltechNativeBridge.onmessage?.({data:JSON.stringify({id:message.id,ok:true,result})});}catch(error){window.VeltechNativeBridge.onmessage?.({data:JSON.stringify({id:message.id,ok:false,error:error.message})});}});}};
 return messages;
}
async function updates(value=release){
 globalThis.__nativeInstallRelease=value;
 const {default:Updates}=await loadJsx(new URL('../src/components/AndroidUpdates.jsx',import.meta.url),{'../lib/api':moduleUrl('export const request=async()=>globalThis.__nativeInstallRelease;'),'./UI':ui});
 let view;await act(async()=>{view=create(React.createElement(Updates));await settle();});return view;
}
test('native update opens the verified Android installer instead of a browser or PWA download',async()=>{
 const env=browserFixture(),messages=installBridge(env.window);let view;
 try{
  view=await updates();const action=view.root.findAllByType('button').find(node=>text(node)==='Install Android update');
  assert.ok(action,'Native APK must use the Android installer action, not an attachment anchor');
  assert.equal(view.root.findAllByType('a').filter(node=>node.props.download).length,0);
  await act(async()=>{await action.props.onClick();await settle();});
  assert.deepEqual(messages.find(item=>item.type==='downloadApk').payload,{url:'https://app.veltech-mini-ams.me'+release.url,sha256:sha,versionCode:20308});
  assert.match(text(view.root),/Android installer opened/);
  assert.doesNotMatch(text(view.root),/Check your browser’s Downloads/);
 }finally{if(view)await act(async()=>view.unmount());env.window.dispatchEvent(new Event('pagehide'));env.restore();delete globalThis.__nativeInstallRelease;}
});
test('current native version cannot reinstall an equal or older APK and shares with Android',async()=>{
 const env=browserFixture(),messages=installBridge(env.window);let view;
 try{
  view=await updates({...release,versionCode:20307,versionName:'2.3.5'});
  const action=view.root.findAllByType('button').find(node=>text(node)==='Android app is up to date');assert.ok(action);assert.equal(action.props.disabled,true);
  await act(async()=>view.root.findAllByType('button').find(node=>text(node)==='Share download page').props.onClick());
  assert.equal(messages.find(item=>item.type==='share').payload.url,'https://app.veltech-mini-ams.me/#/install');
  assert.equal(messages.filter(item=>item.type==='downloadApk').length,0);
 }finally{if(view)await act(async()=>view.unmount());env.window.dispatchEvent(new Event('pagehide'));env.restore();delete globalThis.__nativeInstallRelease;}
});
test('native app never reads or activates a waiting website service worker',async()=>{
 const env=browserFixture();let view,reads=0;installBridge(env.window);
 navigator.serviceWorker={getRegistration:async()=>{reads++;return {waiting:{scriptURL:'/sw.js'}};}};
 try{
  const {default:Notice}=await loadJsx(new URL('../src/components/AppUpdateNotice.jsx',import.meta.url),{'../context/CampusContext':moduleUrl('export const useCampus=()=>({mode:"connected",data:{profile:{id:"fictional-owner"}}});')});
  await act(async()=>{view=create(React.createElement(Notice));await settle();});
  assert.equal(reads,0,'Bundled APK screens must not be overwritten by a website worker');assert.equal(view.root.findAllByType('aside').length,0);
 }finally{if(view)await act(async()=>view.unmount());env.window.dispatchEvent(new Event('pagehide'));env.restore();}
});
