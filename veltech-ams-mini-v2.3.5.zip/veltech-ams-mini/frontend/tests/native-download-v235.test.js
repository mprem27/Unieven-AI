import test from 'node:test';
import assert from 'node:assert/strict';
import {downloadFile} from '../src/lib/download.js';
import {setDownloadOwner} from '../src/lib/device-downloads.js';
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function fixture(handler){
 const previous={window:globalThis.window,document:globalThis.document},window=new EventTarget(),messages=[];
 window.VeltechNativeBridge={postMessage(text){const message=JSON.parse(text);messages.push(message);queueMicrotask(async()=>{try{const result=await handler(message);window.VeltechNativeBridge.onmessage?.({data:JSON.stringify({id:message.id,ok:true,result})});}catch(error){window.VeltechNativeBridge.onmessage?.({data:JSON.stringify({id:message.id,ok:false,error:error.message})});}});}};
 globalThis.window=window;globalThis.document={createElement(){throw new Error('A native save must not create a browser download');}};setDownloadOwner('student-A');
 return {window,messages,restore(){window.dispatchEvent(new Event('pagehide'));globalThis.window=previous.window;globalThis.document=previous.document;setDownloadOwner('demo');}};
}
test('shared exports use the native save dialog and cancellation stays quiet',async()=>{
 const env=fixture(async m=>m.type==='beginFile'?{transferId:'private-file'}:m.type==='finishFile'?{saved:true}:{appended:true});
 try{assert.equal(await downloadFile('results.pdf',new Blob(['fictional result'],{type:'application/pdf'}),'application/pdf',{store:false}),true);assert.ok(env.messages.some(m=>m.type==='finishFile'));}finally{env.restore();}
});
test('switching accounts while the Android save picker is open cancels the private file',async()=>{
 let finishStarted;const opened=new Promise(resolve=>{finishStarted=resolve;});
 const env=fixture(async m=>{if(m.type==='beginFile')return {transferId:'old-student'};if(m.type==='finishFile'){finishStarted();return new Promise(()=>{});}return {cancelled:true};});
 try{
  const pending=downloadFile('private.pdf',new Blob(['private'],{type:'application/pdf'}),'application/pdf',{store:false});
  await Promise.race([opened,new Promise((_,reject)=>setTimeout(()=>reject(new Error('Native save did not open')),2000))]);
  setDownloadOwner('student-B');setDownloadOwner('student-A');
  assert.equal(await pending,false);await tick();assert.ok(env.messages.some(m=>m.type==='cancelFile'),'Owner revocation must close the pending Android picker');
 }finally{env.restore();}
});
test('account revocation before beginFile replies cleans the late native transfer',async()=>{
 let began,release;const started=new Promise(resolve=>{began=resolve;});
 const env=fixture(async m=>{if(m.type==='beginFile'){began();return new Promise(resolve=>{release=resolve;});}return {cancelled:true};});
 try{
  const pending=downloadFile('private.pdf',new Blob(['private'],{type:'application/pdf'}),'application/pdf',{store:false});
  await started;setDownloadOwner('student-B');assert.equal(await pending,false);
  release({transferId:'late-old-account'});await tick();await tick();
  assert.ok(env.messages.some(m=>m.type==='cancelFile' && m.payload.transferId==='late-old-account'),'Late-created private transfer must not block the next student’s save');
 }finally{env.restore();}
});
